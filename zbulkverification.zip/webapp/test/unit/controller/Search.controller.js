/*global QUnit*/

sap.ui.define([
	"zbv/zbulkverification/controller/Search.controller"
], function (Controller) {
	"use strict";

	QUnit.module("Search Controller");

	QUnit.test("I should test the Search controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});