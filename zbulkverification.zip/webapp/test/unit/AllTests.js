sap.ui.define([
	"zbv/zbulkverification/test/unit/controller/Search.controller"
], function () {
	"use strict";
});