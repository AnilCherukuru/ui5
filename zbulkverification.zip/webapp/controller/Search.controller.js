sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/ndc/BarcodeScanner"
], function (Controller, oRouter, oScan) {
	"use strict";

	return Controller.extend("zbv.zbulkverification.controller.Search", {
		onInit: function () {
			// this.onSearch();
		},
		onSearch: function (oEvent) {
			var t = this;
			var iSoNum = oEvent.getSource().getValue();
			// var	iSoNum = "001000001480";
			if (iSoNum !== "") {
				var oModel = this.getOwnerComponent().getModel("oSODetails");
				oModel.setProperty("/SONum", iSoNum);
				this.getRouter().navTo("SODetails", {
					salesorder: iSoNum
				});
				// this.getRouter().getTargets().display("Targetsoheader");
				// }
			}
		},
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		onScan: function (oEvent) {
			var t = this;
			oScan.scan(
				function (mResult) {
					if (mResult) {
						var oModel = t.getOwnerComponent().getModel("oSODetails");
						oModel.setProperty("/SONum", mResult.text);
						// t.byId("searchField").setValue(mResult.text);
						// t.getRouter().navTo("Targetsoheader");
						t.getRouter().navTo("SODetails", {
							salesorder: mResult.text
						});
					}
				},
				function (Error) {
					alert("Scanning failed: " + Error);
				},
			);
		}

	});
});