sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageToast",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/Text"

], function (Controller, History, MessageToast, Dialog, Button, Text) {
	"use strict";

	return Controller.extend("zbv.zbulkverification.controller.SODetails", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf zbv.zbulkverification.view.SODetails
		 */
		onInit: function () {
			var t = this;
			var oData = new sap.ui.model.json.JSONModel({
				SalesOrder: "",
				SalesOrderItem: "",
				SalesOrderItemCategory: '',
				RequestedQuantity: '',
				Material: '',
				"to_SalesOrder": {
					SalesOrder: ""
				}
			});
			this.getView().setModel(oData, "oNData");
			t.getView().setBusy(true);
			var SOR;
			this.getRouter().attachRouteMatched(function (oEvent) {

					SOR = oEvent.getParameters().arguments.salesorder;

					var oJModel = t.getOwnerComponent().getModel("oSODetails");
					var oVModel = t.getOwnerComponent().getModel("oHead");
					var of4FilterNoGrd = new Array();
					of4FilterNoGrd[0] = new sap.ui.model.Filter("Codegruppe", sap.ui.model.FilterOperator.EQ, 'NO-GRADE');

					oVModel.read('/ZshInspCatalogSet', {
						success: jQuery.proxy(this._setF4NOGRADE, this),
						filters: of4FilterNoGrd
					});

					var of4FilterCSC = new Array();
					of4FilterCSC[0] = new sap.ui.model.Filter("Codegruppe", sap.ui.model.FilterOperator.EQ, 'CN-STR-C');

					oVModel.read('/ZshInspCatalogSet', {
						success: jQuery.proxy(this._setF4CSC, this),
						filters: of4FilterCSC
					});

					var oSONum = oJModel.getProperty("/SONum");
					if (!oSONum) {
						oSONum = SOR;
						oJModel.setProperty("/SONum", SOR);
					}
					// var oModel = t.getOwnerComponent().getModel("oSODetail");

					// oModel.read("/A_SalesOrder", {
					// 	success: jquery.proxy
					// });
					// var t = this;
					var oFilter = new Array();
					oFilter[0] = new sap.ui.model.Filter("SalesOrder", sap.ui.model.FilterOperator.EQ, oSONum);
					var oModel = new sap.ui.model.odata.ODataModel(t.getOwnerComponent().getModel("oSODetail").sServiceUrl, {
						refreshAfterChange: true
					});
					var path = "A_SalesOrder?$filter=SalesOrder eq '" + oSONum + "'";

					oModel.read(path, null, null, null, function (oData, oResponse) {
							sap.ui.core.BusyIndicator.hide();
							t.getView().setBusy(false);
							oJModel.setProperty("/SONum", oData.results[0].SalesOrder);
							// oJModel.setProperty("/TotalNetAmount", oData.results[0].TotalNetAmount);

							// oJModel.setProperty("/RDate", oData.results[0].CreationDate);
							oJModel.setProperty("/MinStrike", oData.results[0].ZZ1_MinimumStrike_SDH);
						},
						function (oError) {
							t.getView().setBusy(false);
							// 				sap.ui.core.BusyIndicator.hide();
							// //				var message = JSON.parse(oError.responseText).error.message.value;
							// 				sap.m.MessageBox.show("Record Not Created", {
							// 					icon: sap.m.MessageBox.Icon.ERROR,
							// 					title: "Error",
							// 					actions: [sap.m.MessageBox.Action.OK],
							// 					onClose: function(OAction) {
							// 						if (OAction === sap.m.MessageBox.Action.OK) {}
							// 					}
							// 				});

						});
					// var oFilterItm = new Array();
					// oFilterItm[0] = new sap.ui.model.Filter("SalesOrder", sap.ui.model.FilterOperator.EQ, oSONum);
					// var oModel = new sap.ui.model.odata.ODataModel(t.getOwnerComponent().getModel("oSODetail").sServiceUrl, {
					// 	refreshAfterChange: true
					// });
					path = "A_SalesOrderItem?$filter=SalesOrder eq '" + oSONum + "' and SalesOrderItemCategory eq '" + "ZZAN" + "'";

					oModel.read(path, null, null, null, function (oData, oResponse) {
							var odata = {
								SalesOrderItem: "",
								SalesOrderItemCategory: '',
								RequestedQuantity: '',
								Material: '',
								ZZ1_YEAR_SDI: '',
								ZZ1_DENOM_SDI: '',
								ZZ1_CNSTRIK_SDI: '',
								ZZ1_Collectible_SDI: '',

								ZZ1_Pedigree_SDI: '',
								ZZ1_Core_SDI: '',
								ZZ1_LabelType_SDI: '',
								ZZ1_Grade_SDI: '',
								ZZ1_Plus_SDI: '',
								ZZ1_Star_SDI: '',
								ZZ1_Grader_SDI: '',
								ZZ1_GradingDate_SDI: '',
								MarketValue: '',
								EstPrice: '',
								ZZ1_HolderType_SDI: '',
								// NoGraded: '',
								// ConsrNeeded: ''

							};
							sap.ui.core.BusyIndicator.hide();
							t.getView().setBusy(false);
							var oNModel = t.getView().getModel("oNData");

							oJModel.setProperty("/DSOITEM", oData.results[0]);
							var SoitemORG = new Array();
							var SoitemVER = new Array();
							var otableIndex1 = 0;
							// var otableIndex2 = 0;
							for (var i = 0; i < oData.results.length; i++) {
								// var oNSOData = oNModel.getData();
								var oNSOData = {
									SalesOrder: "",
									SalesOrderItem: "",
									SalesOrderItemCategory: '',
									RequestedQuantity: '',
									Material: '',
									ZZ1_YEAR_SDI: '',
									ZZ1_DENOM_SDI: '',
									ZZ1_CNSTRIK_SDI: '',
									ZZ1_Collectible_SDI: '',
									ZZ1_Pedigree_SDI: '',
									ZZ1_Core_SDI: '',
									ZZ1_Core_SDI_TEXT: '',
									ZZ1_LabelType_SDI: '',
									ZZ1_LabelType_SDI_TEXT: '',
									ZZ1_Grade_SDI: '',
									ZZ1_Plus_SDI: '',
									ZZ1_Star_SDI: '',
									ZZ1_Grader_SDI: '',
									ZZ1_GradingDate_SDI: '',
									// MarketValue: '',
									// EstPrice: '',
									ZZ1_HolderType_SDI: '',
									ZZ1_HolderType_SDI_TEXT: '',
									// NoGraded: '',
									// ConsrNeeded: '',
									"to_SalesOrder": {
										SalesOrder: ""
									}
								};
								var oProduct = oData.results[i];
								if (oProduct.MaterialByCustomer === "" || oProduct.MaterialByCustomer === "ORIGINAL") {

									SoitemORG[otableIndex1] = oProduct;
									otableIndex1 = otableIndex1 + 1;
								}
								if (oProduct.MaterialByCustomer === "VERIFIED") {

									// oNSOData.SalesOrder = oProduct.SalesOrder;
									// oNSOData.to_SalesOrder.SalesOrder = oProduct.SalesOrder;
									// oNSOData.SalesOrderItem = oProduct.SalesOrderItem;
									// oNSOData.SalesOrderItemCategory = oProduct.SalesOrderItemCategory;
									// oNSOData.RequestedQuantity = oProduct.RequestedQuantity;
									// oNSOData.Material = oProduct.Material;
									// oNSOData.ZZ1_YEAR_SDI = oProduct.ZZ1_YEAR_SDI;
									// oNSOData.ZZ1_DENOM_SDI = oProduct.ZZ1_DENOM_SDI;
									// oNSOData.ZZ1_CNSTRIK_SDI = oProduct.ZZ1_CNSTRIK_SDI;
									// oNSOData.ZZ1_Collectible_SDI = oProduct.ZZ1_Collectible_SDI;
									// oNSOData.ZZ1_Pedigree_SDI = oProduct.ZZ1_Pedigree_SDI;
									// oNSOData.ZZ1_Core_SDI = oProduct.ZZ1_Core_SDI;
									// oNSOData.ZZ1_LabelType_SDI = oProduct.ZZ1_LabelType_SDI;
									// oNSOData.ZZ1_Grade_SDI = oProduct.ZZ1_Grade_SDI;
									// oNSOData.ZZ1_Plus_SDI = false;
									// oNSOData.ZZ1_Star_SDI = false;
									// oNSOData.ZZ1_Grader_SDI = oProduct.ZZ1_Grader_SDI;
									// oNSOData.ZZ1_GradingDate_SDI = oProduct.ZZ1_GradingDate_SDI;
									// oNSOData.ZZ1_GradingTime_SDI = oProduct.ZZ1_GradingTime_SDI;
									// // oNSOData.MarketValue = oProduct.MarketValue;
									// // oNSOData.EstPrice = oProduct.EstPrice;
									// oNSOData.ZZ1_HolderType_SDI = oProduct.ZZ1_HolderType_SDI;
									// oNSOData.ZZ1_NOGRADE_SDI = oProduct.ZZ1_NOGRADE_SDI;
									// oNSOData.ZZ1_CONSRVREQ_SDI = false;

									// SoitemVER.push(oNSOData);

									// SoitemVER[otableIndex2] = oNSOData;
									// otableIndex2 = otableIndex2 + 1;
								}

							}

							// otableIndex1 = 0;
							// otableIndex2 = 0;
							var oLen = oData.results.length - 1;
							var oSOITEM = oData.results[oLen].SalesOrderItem;
							var oItem = oLen;
							// var oItem = parseInt(oSOITEM, 10);
							// var oRecone = oData.results[0];
							// var val = "";
							// t.setAll(oRecone, val);

							if (SoitemVER.length < 5) {
								i = SoitemVER.length;
								do {
									i++;
									var oNSOData1 = {
										SNO: "",
										SalesOrder: "",
										SalesOrderItem: "",
										SalesOrderItemCategory: '',
										RequestedQuantity: '',
										Material: '',
										Material_TEXT: '',
										ZZ1_YEAR_SDI: '',
										ZZ1_DENOM_SDI: '',
										ZZ1_CNSTRIK_SDI: '',
										ZZ1_Collectible_SDI: '',

										ZZ1_Pedigree_SDI: '',
										ZZ1_Core_SDI: '',
										ZZ1_LabelType_SDI: '',
										ZZ1_Grade_SDI: '',
										ZZ1_Plus_SDI: false,
										ZZ1_Star_SDI: false,
										ZZ1_Grader_SDI: "",
										ZZ1_GradingDate_SDI: new Date(),
										ZZ1_GradingTime_SDI: new Date(),
										// MarketValue: '',
										// EstPrice: '',
										ZZ1_HolderType_SDI: '',
										ZZ1_NoGrade_SDI: '',
										MaterialByCustomer: '',
										ZZ1_DETYP_SDI: '',
										// ConsrNeeded: false,
										"to_SalesOrder": {
											SalesOrder: ""
										}
									};

									oItem = oItem + 1;
									var oItemTxt = oItem.toString();
									oNSOData1.SalesOrder = oSONum;
									oNSOData1.SNO = i;
									SoitemVER.push(oNSOData1);
								}
								while (i < 5);
							}
							// }
							oJModel.setProperty("/SOITEM", SoitemORG);
							oJModel.setProperty("/CSOITEM", SoitemVER);

						},
						function (oError) {
							t.getView().setBusy(false);
							// 				sap.ui.core.BusyIndicator.hide();
							// //				var message = JSON.parse(oError.responseText).error.message.value;
							// 				sap.m.MessageBox.show("Record Not Created", {
							// 					icon: sap.m.MessageBox.Icon.ERROR,
							// 					title: "Error",
							// 					actions: [sap.m.MessageBox.Action.OK],
							// 					onClose: function(OAction) {
							// 						if (OAction === sap.m.MessageBox.Action.OK) {}
							// 					}
							// 				});

						});
					// var oVModel = this.getOwnerComponent().getModel("oHead");
					var oURLparams = {
						"SalesOrder": oSONum

					};
					oVModel.callFunction('/GetPartnerAddress', {
						method: "GET",
						urlParameters: oURLparams,
						success: jQuery.proxy(this._setPartnerAddress, this)
					});

					// oVModel.callFunction('/GetVerifStock', {
					// 	method: "GET",
					// 	urlParameters: oURLparams,
					// 	success: jQuery.proxy(this._setVerifStock, this)
					// });

				},
				//oURLparams = {
				// 	"SalesOrder": oSONum

				// };

				this);

		},

		setAll: function (obj, val) {
			/* Duplicated with @Maksim Kalmykov
			    for(index in obj) if(obj.hasOwnProperty(index))
			        obj[index] = val;
			*/
			Object.keys(obj).forEach(function (index) {
				obj[index] = val;
			});
		},
		_setPartnerAddress: function (oData, oReponse) {

			var oresults = oData.results;
			var oHModel = this.getView().getModel("oSODetails");
			for (var i = 0; i < oresults.length; i++) {
				if (oresults[i].PartnerType === "SB") {
					oHModel.setProperty("/CName", oresults[i].Name);
					var streetAdr = oresults[i].Street + ',' + oresults[i].PostCode1;
					oHModel.setProperty("/CStreet", streetAdr);
					var CtryAdr = oresults[i].City1 + ',' + oresults[i].Region;
					oHModel.setProperty("/CCtryAdr", CtryAdr);
					oHModel.setProperty("/CCtry", oData.results[i].Country);

				}
				if (oresults[i].PartnerType === "SP") {
					oHModel.setProperty("/SName", oresults[i].Name);
					streetAdr = oresults[i].Street + ',' + oresults[i].PostCode1;
					oHModel.setProperty("/SStreet", streetAdr);
					CtryAdr = oresults[i].City1 + ',' + oresults[i].Region;
					oHModel.setProperty("/SCtryAdr", CtryAdr);
					oHModel.setProperty("/SCtry", oData.results[i].Country);

				}

			}
		},
		_setVerifStock: function (oData, oResponse) {
			var oJModel = this.getOwnerComponent().getModel("oSODetails");
			var oOTABLE = oJModel.getProperty("/SOITEM");
			// var oTable = "/DSOITEM/";
			for (var i = 0; i < oOTABLE.length; i++) {
				for (var j = 0; j < oData.results.length; j++) {
					if (oOTABLE[i].SalesOrderItem === oData.results[j].Salesitem) {
						oOTABLE[i].RequestedQuantity = oData.results[j].Stock;
						oOTABLE[i].Material = oData.results[j].Material;
						oOTABLE[i].ZZ1_HolderType_SDI = oData.results[j].Holdertype;
						oOTABLE[i].ZZ1_Core_SDI = oData.results[j].Coretype;
						oOTABLE[i].ZZ1_LabelType_SDI = oData.results[j].Labeltype;
					}
				}
			}
			// var oTindex = oTable + "" + j;
			// oJModel.setProperty(oTindex + "/RequestedQuantity", oData.results[j].Stock);

			// var oSOTable = oJModel.getProperty("/SOITEM");
			// for(var i=0;i<oData.results.length;i++){

			// }
			oJModel.setProperty("/TotalNetAmount", oData.results[0].TotalStock);
			oJModel.setProperty("/RDate", new Date());
		},
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		handleF4Euq: function (oEvent) {
			var rowContextPath = oEvent.getSource().getBindingContext("oSODetails").getPath();

			var oModelSoD = this.getOwnerComponent().getModel("oSODetails");
			oModelSoD.setProperty("/TableIndx", rowContextPath);
			var oModel = this.getOwnerComponent().getModel("oHead");
			var of4FilterEuq = new Array();
			of4FilterEuq[0] = new sap.ui.model.Filter("Eqtyp", sap.ui.model.FilterOperator.EQ, 'C');
			oModel.read('/ZshEquipmentMasterSet', {
				success: jQuery.proxy(this._setF4Euq, this),
				filters: of4FilterEuq
			});
			// var oHModel = this.getView().getModel("oSODetails");
			// oHModel.setProperty("/f4equip", "");

			var oModelH = this.getView().getModel("oSODetails");
			oModelH.setProperty("/f4equip", "");
			oModelH.setProperty("/f4Year", "");
			oModelH.setProperty("/f4mimtm", "");
			oModelH.setProperty("/f4msnum", "");
			oModelH.setProperty("/f4denom", "");

			if (!this.onf4EUQhelpdialog) {
				this.onf4EUQhelpdialog = sap.ui.xmlfragment("zbv.zbulkverification.view.onf4Euq", this);
				this.getView().addDependent(this.onf4EUQhelpdialog);
			}
			this.onf4EUQhelpdialog.open();
		},
		handleF4HolderType: function (oEvent) {
			var rowContextPath = oEvent.getSource().getBindingContext("oSODetails").getPath();

			var oModelSoD = this.getOwnerComponent().getModel("oSODetails");
			oModelSoD.setProperty("/TableIndxHLD", rowContextPath);
			var oFilterPI = new Array();
			var oMat = "HOLDER";
			oFilterPI[0] = new sap.ui.model.Filter("ProductGroup", sap.ui.model.FilterOperator.EQ, oMat);

			var oModelPI = this.getOwnerComponent().getModel("oProductImage");
			oModelPI.read('/C_Product', {
				success: jQuery.proxy(this._setHolderType, this),
				filters: oFilterPI
			});

			if (!this.onf4HLDTYPhelpdialog) {
				this.onf4HLDTYPhelpdialog = sap.ui.xmlfragment("zbv.zbulkverification.view.onf4HLDTYP", this);
				this.getView().addDependent(this.onf4HLDTYPhelpdialog);
			}
			this.onf4HLDTYPhelpdialog.open();
		},
		handleSelectedHLDTYP: function (oEvent) {
			// this.getView().byId("HLDTYPtable1").getTable().getSelectedContexts();
			var oModel = this.getOwnerComponent().getModel("oJModel");
			var oTindex = oModel.getProperty("/TableIndxHLD");
			var selectedObjtyp = oEvent.getSource().getBindingContext("oSODetails").getObject();
			oModel.setProperty(oTindex + "/ZZ1_HolderType_SDI", selectedObjtyp.Product);
			oModel.setProperty(oTindex + "/ZZ1_HolderType_SDI_TEXT", selectedObjtyp.ProductDescription);
			this.onf4HLDTYPhelpdialog.close();
		},
		handleF4Core: function (oEvent) {
			var rowContextPath = oEvent.getSource().getBindingContext("oSODetails").getPath();

			var oModelSoD = this.getOwnerComponent().getModel("oSODetails");
			oModelSoD.setProperty("/TableIndxCORE", rowContextPath);
			var oFilterPI = new Array();
			var oMat = "CORE";
			oFilterPI[0] = new sap.ui.model.Filter("ProductGroup", sap.ui.model.FilterOperator.EQ, oMat);

			var oModelPI = this.getOwnerComponent().getModel("oProductImage");
			oModelPI.read('/C_Product', {
				success: jQuery.proxy(this._setF4Core, this),
				filters: oFilterPI
			});

			if (!this.onf4COREhelpdialog) {
				this.onf4COREhelpdialog = sap.ui.xmlfragment("zbv.zbulkverification.view.onf4CORE", this);
				this.getView().addDependent(this.onf4COREhelpdialog);
			}
			this.onf4COREhelpdialog.open();
		},
		handleF4LABEL: function (oEvent) {
			var rowContextPath = oEvent.getSource().getBindingContext("oSODetails").getPath();

			var oModelSoD = this.getOwnerComponent().getModel("oSODetails");
			oModelSoD.setProperty("/TableIndxLABEL", rowContextPath);

			var oFilterPI = new Array();
			var oMat = "LABEL";
			oFilterPI[0] = new sap.ui.model.Filter("ProductGroup", sap.ui.model.FilterOperator.EQ, oMat);

			var oModelPI = this.getOwnerComponent().getModel("oProductImage");
			oModelPI.read('/C_Product', {
				success: jQuery.proxy(this._setF4Label, this),
				filters: oFilterPI
			});

			if (!this.onf4LABELhelpdialog) {
				this.onf4LABELhelpdialog = sap.ui.xmlfragment("zbv.zbulkverification.view.onf4LABEL", this);
				this.getView().addDependent(this.onf4LABELhelpdialog);
			}
			this.onf4LABELhelpdialog.open();
		},
		handleSelectedLABEL: function (oEvent) {
			var oModel = this.getOwnerComponent().getModel("oSODetails");
			var oTindex = oModel.getProperty("/TableIndxLABEL");
			var selectedObjtyp = oEvent.getSource().getBindingContext("oSODetails").getObject();
			oModel.setProperty(oTindex + "/ZZ1_LabelType_SDI", selectedObjtyp.Product);
			oModel.setProperty(oTindex + "/ZZ1_LabelType_SDI_TEXT", selectedObjtyp.ProductDescription);
			this.onf4LABELhelpdialog.close();
		},
		_setF4Euq: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oSODetails");
			oHModel.setProperty("/f4Equip", oData.results);
		},
		_setF4Core: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oSODetails");
			oHModel.setProperty("/F4CORE", oData.results);
		},
		_setF4Label: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oSODetails");
			oHModel.setProperty("/f4Label", oData.results);
		},
		_setHolderType: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oSODetails");
			oHModel.setProperty("/f4HoldType", oData.results);
		},
		handleEuqClose: function () {
			this.onf4EUQhelpdialog.close();
		},
		handleHLDTYPClose: function () {
			this.onf4HLDTYPhelpdialog.close();
		},
		handleCOREClose: function () {
			this.onf4COREhelpdialog.close();
		},
		handleSelectedEUQCode: function (oEvent) {
			// this.getView().byId("EUQtable1").getTable().getSelectedContexts();
			var oModel = this.getOwnerComponent().getModel("oSODetails");
			var oTindex = oModel.getProperty("/TableIndx");
			var selectedObjtyp = oEvent.getSource().getBindingContext("oSODetails").getObject();
			oModel.setProperty(oTindex + "/Material", selectedObjtyp.Mapar);
			oModel.setProperty(oTindex + "/Material_TEXT", selectedObjtyp.Maktx);
			oModel.setProperty(oTindex + "/ZZ1_Collectible_SDI", selectedObjtyp.Equnr);
			oModel.setProperty(oTindex + "/ZZ1_YEAR_SDI", selectedObjtyp.Herst);
			oModel.setProperty(oTindex + "/ZZ1_DENOM_SDI", selectedObjtyp.Typbz);
			oModel.setProperty(oTindex + "/ZZ1_CNSTRIK_SDI", selectedObjtyp.Eqart);
			this.onf4EUQhelpdialog.close();
		},
		handleSelectedCORETYP: function (oEvent) {
			var oModel = this.getOwnerComponent().getModel("oSODetails");
			var oTindex = oModel.getProperty("/TableIndxCORE");
			var selectedObjtyp = oEvent.getSource().getBindingContext("oSODetails").getObject();
			oModel.setProperty(oTindex + "/ZZ1_Core_SDI", selectedObjtyp.Product);
			oModel.setProperty(oTindex + "/ZZ1_Core_SDI_TEXT", selectedObjtyp.ProductDescription);
			this.onf4COREhelpdialog.close();
		},
		handleSOPress: function (oEvent) {

			var SO = oEvent.getSource().getText();

			this.oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");

			this.oCrossAppNav.toExternal({
				target: {
					semanticObject: "SalesOrder",
					action: "displayFactSheet"
				},
				params: {
					SalesOrder: SO
				}

			});

		},
		onCreate: function (oEvent) {
			var t = this;
			var oSIndex = 0;
			var oTIndex = 0;
			t.getView().setBusy(true);
			var oJModel = t.getOwnerComponent().getModel("oSODetails");
			var oResults = oJModel.getProperty("/CSOITEM");
			var oModel = t.getOwnerComponent().getModel("oSODetail");
			for (var i = 0; i < oResults.length; i++) {
				if (oResults[i].ZZ1_Collectible_SDI !== "") {
					oTIndex = oTIndex + 1;
				}
			}

			for (var i = 0; i < oResults.length; i++) {
				if (oResults[i].ZZ1_Collectible_SDI !== "") {
					delete oResults[i].ZZ1_Core_SDI_TEXT;
					delete oResults[i].ZZ1_LabelType_SDI_TEXT;
					delete oResults[i].ZZ1_HolderType_SDI_TEXT;
					delete oResults[i].ZZ1_GradingTime_SDI;
					delete oResults[i].Material_TEXT;
					// delete oResults[i].ZZ1_NOGRADE_SDI;
					delete oResults[i].ZZ1_CONSRVREQ_SDI;
					delete oResults[i].SNO;
					// delete oResults[i].MarketValue;
					// delete oResults[i].EstPrice;
					// delete oResults[i].NoGraded;
					oResults[i].SalesOrderItem = "";
					var oDenom = oResults[i].ZZ1_DENOM_SDI;
					oResults[i].ZZ1_DETYP_SDI = oDenom.substring(0, 1);
					oResults[i].SalesOrderItemCategory = "ZZAN";
					oResults[i].MaterialByCustomer = "VERIFIED";

					// oResults[i].Material = "MM02";
					// oResults[i].RequestedQuantity = "2";
					oModel.create("/A_SalesOrderItem", oResults[i], {
						success: function () {

							t.getView().setBusy(false);
							var SuccessMsg1 = "Submission Order Item Created Successfully";
							sap.m.MessageBox.show(SuccessMsg1, {
								icon: sap.m.MessageBox.Icon.SUCCESS,
								title: "Success",
								actions: [sap.m.MessageBox.Action.OK],
								onClose: function (OAction) {
									if (OAction === sap.m.MessageBox.Action.OK) {
										oSIndex = oSIndex + 1;
										if (oSIndex === oTIndex) {
											window.history.go(-1);
										}
									}
								}
							});
							// window.history.go(-1);
						},
						error: function (oError) {
							t.getView().setBusy(false);
							var message = JSON.parse(oError.responseText).error.message.value;
							sap.m.MessageBox.show(message, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Error",
								actions: [sap.m.MessageBox.Action.OK],
								onClose: function (OAction) {
									if (OAction === sap.m.MessageBox.Action.OK) {
										// window.history.go(-1);
									}
								}
							});
						}

					});
				}
			}
			t.getView().setBusy(false);
		},

		handleSelectedCSTRK: function (oEvent) {
			var selectedObjtyp = oEvent.getSource().getBindingContext("oHead").getObject().Code;
			var selectedObjtypText = oEvent.getSource().getBindingContext("oHead").getObject().Kurztext;

			this.byId("i1CoinStrike").setValue(selectedObjtyp);
			this.byId("i1TCoinStrike").setText(selectedObjtypText);
			// var oModel = this.getView().getModel("oMain");
			// var oData = oModel.getData();
			// oData.VMintMark = selectedObjtyp;
			// oModel.setData(oData);
			this.onf4CShelpdialog.close();
		},

		handleF4NoGrade: function (oEvent) {
			var rowContextPath = oEvent.getSource().getBindingContext("oSODetails").getPath();

			var oModelSoD = this.getOwnerComponent().getModel("oSODetails");
			oModelSoD.setProperty("/TableIndxNG", rowContextPath);
			if (!this.onf4NoGhelpdialog) {
				this.onf4NoGhelpdialog = sap.ui.xmlfragment("zbv.zbulkverification.view.onf4NoGhelpdialog", this);
				this.getView().addDependent(this.onf4NoGhelpdialog);
			}
			this.onf4NoGhelpdialog.open();
		},

		_setF4NOGRADE: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oSODetails");
			oHModel.setProperty("/f4NOGRADE", oData.results);
		},

		handleF4CoinStrikeChar: function (oEvent) {
			var rowContextPath = oEvent.getSource().getBindingContext("oSODetails").getPath();

			var oModelSoD = this.getOwnerComponent().getModel("oSODetails");
			oModelSoD.setProperty("/TableIndxCS", rowContextPath);
			if (!this.onf4CSChelpdialog) {
				this.onf4CSChelpdialog = sap.ui.xmlfragment("zbv.zbulkverification.view.onf4CoinStrikeChar", this);
				this.getView().addDependent(this.onf4CSChelpdialog);
			}
			this.onf4CSChelpdialog.open();
		},

		_setF4CSC: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oSODetails");
			oHModel.setProperty("/f4CSC", oData.results);
		},
		handleSelectedCSTRKCHAR: function (oEvent) {
			var oModel = this.getOwnerComponent().getModel("oSODetails");
			var oTindex = oModel.getProperty("/TableIndxCS");
			var selectedObjtyp = oEvent.getSource().getBindingContext("oSODetails").getObject();
			oModel.setProperty(oTindex + "/ZZ1_MintMark_SDI", selectedObjtyp.Code);
			// oModel.setProperty(oTindex + "/ZZ1_Core_SDI_TEXT", selectedObjtyp.ProductDescription);
			this.onf4CSChelpdialog.close();
		},
		handleSelectedNG: function (oEvent) {
			var oModel = this.getOwnerComponent().getModel("oSODetails");
			var oTindex = oModel.getProperty("/TableIndxNG");
			var selectedObjtyp = oEvent.getSource().getBindingContext("oSODetails").getObject();
			oModel.setProperty(oTindex + "/ZZ1_NoGrade_SDI", selectedObjtyp.Code);
			// oModel.setProperty(oTindex + "/ZZ1_Core_SDI_TEXT", selectedObjtyp.ProductDescription);
			this.onf4NoGhelpdialog.close();
		},
		handleEuqSearch: function () {
			var oModel = this.getOwnerComponent().getModel("oHead");
			var oModelH = this.getView().getModel("oSODetails");
			var oEqunr = oModelH.getProperty("/f4equip");
			var oYear = oModelH.getProperty("/f4Year");
			var oMapar = oModelH.getProperty("/f4mimtm");
			var oSerge = oModelH.getProperty("/f4msnum");
			var oTypbz = oModelH.getProperty("/f4denom");
			if (!oEqunr) {
				oEqunr = "";
			}
			if (!oYear) {
				oYear = "";
			}
			if (!oMapar) {
				oMapar = "";
			}
			if (!oSerge) {
				oSerge = "";
			}
			if (!oTypbz) {
				oTypbz = "";
			}

			var of4FilterEuq = new Array();
			of4FilterEuq[0] = new sap.ui.model.Filter("Equnr", sap.ui.model.FilterOperator.Contains, oEqunr);
			of4FilterEuq[1] = new sap.ui.model.Filter("Eqart", sap.ui.model.FilterOperator.Contains, oSerge);
			of4FilterEuq[2] = new sap.ui.model.Filter("Maktx", sap.ui.model.FilterOperator.Contains, oMapar);
			of4FilterEuq[3] = new sap.ui.model.Filter("Herst", sap.ui.model.FilterOperator.Contains, oYear);
			of4FilterEuq[4] = new sap.ui.model.Filter("Typbz", sap.ui.model.FilterOperator.Contains, oTypbz);
			oModel.read('/ZshEquipmentMasterSet', {
				success: jQuery.proxy(this._setF4Euq, this),
				filters: of4FilterEuq
			});

		},
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf zbv.zbulkverification.view.SODetails
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf zbv.zbulkverification.view.SODetails
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf zbv.zbulkverification.view.SODetails
		 */
		//	onExit: function() {
		//
		//	}

	});

});