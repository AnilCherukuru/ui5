sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
	"use strict";
	return Controller.extend("zcv.zcoin_grading.blocks.ItemBlock1", {
		onInit: function () {

		}

	});
});