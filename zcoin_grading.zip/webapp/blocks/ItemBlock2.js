sap.ui.define(["sap/uxap/BlockBase"], function (B) {
	"use strict";
	return B.extend("zcv.zcoin_grading.blocks.ItemBlock2", {
		metadata: {
			views: {
				Collapsed: {
					viewName: "zcv.zcoin_grading.blocks.ItemBlock2",
					type: "XML"
				},
				Expanded: {
					viewName: "zcv.zcoin_grading.blocks.ItemBlock2",
					type: "XML"
				}
			},
			events: {}
		}
	});
});