sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/ndc/BarcodeScanner"
], function (Controller, History, oScan) {
	"use strict";

	return Controller.extend("zcv.zcoin_grading.controller.SearchSO", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf zcv.zcoin_grading.view.SearchSO
		 */
		onInit: function () {
			// this.getRouter().getTargets().display("notFound");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("soView").attachPatternMatched(this._onObjectMatched, this);

			// this.getRouter().attachRouteMatched(this._onRouteMatched, this);
		},
		_onObjectMatched: function () {

		},
		onScan: function (oEvent) {
			var t = this;
			oScan.scan(
				function (mResult) {
					// t.byId("searchField").setValue("");
					// alert("We got a bar code\n" +
					// 	"Result: " + mResult.text + "\n" +
					// 	"Format: " + mResult.format + "\n" +
					// 	"Cancelled: " + mResult.cancelled);
					if (mResult) {
						var oModel = t.getOwnerComponent().getModel("oMainModel");
						oModel.setProperty("/iptsoNum", mResult.text);
						// t.byId("searchField").setValue(mResult.text);
						// t.getRouter().navTo("Targetsoheader");
						// t.getRouter().getTargets().display("Targetsoheader");
						// t.byId("searchField").setValue(mResult.text);
						t.getRouter().navTo("Routesoheader", {
							salesorder: mResult.text
						});

						// this.getRouter().navTo("Routesoheader", {
						// 	salesorder: mResult.text
						// });

						// this.getRouter().Initiali
					}
				},
				function (Error) {
					alert("Scanning failed: " + Error);
				},
			);
		},
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		onSearch: function (oEvent) {
			var t = this;
			var oSONum = oEvent.getSource().getValue();
			if (oSONum !== "") {
				var oModel = this.getOwnerComponent().getModel("oMainModel");
				oModel.setProperty("/iptsoNum", oSONum);

				// t.byId("searchField").setValue(oSONum);
				// t.getRouter().navTo("Targetsoheader");
				// this.getRouter().getTargets().display("Targetsoheader");

				// var iSoNumItem = oEvent.getSource().getValue();
				// if (iSoNumItem !== "") {
				// var oModel = this.getOwnerComponent().getModel("oMainModel");
				// oModel.setProperty("/iptsoItemNum", iSoNumItem);
				// 
				// t.byId("searchFieldSOITEM").setValue(iSoNumItem);
				// t.getRouter().navTo("Targetsoheader");
				// var oHistory = History.getInstance();
				// var sPreviousHash = oHistory.getPreviousHash();

				// if (sPreviousHash !== undefined) {
				// 	window.history.go(-1);
				// } else {
				// this.getRouter().getTargets().display("Targetsoheader");
				// this.oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");

				// this.oCrossAppNav.toExternal({
				// 	target: {
				// 		semanticObject: "Equipment",
				// 		action: "GradingHistory"
				// 	}
				this.getRouter().navTo("Routesoheader", {
					salesorder: oSONum
				});

				// this.getRouter().getTargets().display("Targetsoheader");
				// // });
				// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				// oRouter.navTo("Routesoheader", true);
				// }
				// this.getRouter().getTargets().display("Targetsoheader");
				// }
			}
			// oScan.scan(
			// 	function (mResult) {
			// 		// t.byId("searchField").setValue("cde");
			// 		// alert("We got a bar code\n" +
			// 		// 	"Result: " + mResult.text + "\n" +
			// 		// 	"Format: " + mResult.format + "\n" +
			// 		// 	"Cancelled: " + mResult.cancelled);
			// 		// if (!mResult) {
			// 		// t.byId("searchField").setValue('0000000025');
			// 		// this.getRouter().Initiali
			// 		// }
			// 	},
			// 	function (Error) {
			// 		// alert("Scanning failed: " + Error);
			// 	},
			// );
		},
		onNavBack: function () {
			window.history.go(-1);
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf zcv.zcoin_grading.view.SearchSO
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf zcv.zcoin_grading.view.SearchSO
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf zcv.zcoin_grading.view.SearchSO
		 */
		//	onExit: function() {
		//
		//	}

	});

});