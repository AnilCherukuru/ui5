sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
	"use strict";
	return Controller.extend("zcv.zcoin_final_grading.blocks.ItemBlock1", {
		onInit: function () {

		},
		handleF4MintMark: function () {
			if (!this.onf4MMhelpdialog) {
				this.onf4MMhelpdialog = sap.ui.xmlfragment("zcv.zcoin_final_grading.view.onf4MintMark", this);
				this.getView().addDependent(this.onf4MMhelpdialog);
			}
			this.onf4MMhelpdialog.open();
		},
		onSaveItem1: function () {

		}

	});
});