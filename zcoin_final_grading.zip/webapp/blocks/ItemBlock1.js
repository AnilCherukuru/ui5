sap.ui.define(["sap/uxap/BlockBase"], function (B) {
	"use strict";
	return B.extend("zcv.zcoin_final_grading.blocks.ItemBlock1", {
		metadata: {
			views: {
				Collapsed: {
					viewName: "zcv.zcoin_final_grading.blocks.ItemBlock1",
					type: "XML"
				},
				Expanded: {
					viewName: "zcv.zcoin_final_grading.blocks.ItemBlock1",
					type: "XML"
				}
			},
			events: {}
		}
	});
});