sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
	"use strict";
	return Controller.extend("zcv.zcoin_final_grading.blocks.ItemBlock1", {
		onInit: function () {
			this.oFormatDdmmyyyy = sap.ui.core.format.DateFormat.getInstance({
				pattern: "dd.MM.yyyy",
				calendarType: sap.ui.core.CalendarType.Gregorian
			});
		}

	});
});