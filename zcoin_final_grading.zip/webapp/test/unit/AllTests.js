sap.ui.define([
	"zcv/zcoin_verification/test/unit/controller/soheader.controller"
], function () {
	"use strict";
});