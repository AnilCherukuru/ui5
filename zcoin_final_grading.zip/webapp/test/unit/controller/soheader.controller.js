/*global QUnit*/

sap.ui.define([
	"zcv/zcoin_verification/controller/soheader.controller"
], function (Controller) {
	"use strict";

	QUnit.module("soheader Controller");

	QUnit.test("I should test the soheader controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});