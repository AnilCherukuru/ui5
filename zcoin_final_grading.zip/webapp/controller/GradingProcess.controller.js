sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/Text"
], function (Controller, oJSON, MessageToast, Dialog, Button, Text) {
	"use strict";

	return Controller.extend("zcv.zcoin_final_grading.controller.VerificationProcess", {
		onInit: function () {
			var SOR;
			this.getRouter().attachRouteMatched(function (oEvent) {
				SOR = oEvent.getParameters().arguments.salesorder;
				this.oObjectPageLayout = this.byId("itemOverview");
				// this.oObjectPageLayout.removeAllSections();
				var oFilter = new Array();
				var oModelSO = this.getOwnerComponent().getModel("oMainModel");
				// var SO = oModelSO.getProperty("/iptsoNum");
				// var SOItem = oModelSO.getProperty("/iptsoItemNum");
				// var salesorder = SO;
				// var salesorderitem = SOItem;
				var SO = oModelSO.getProperty("/iptsoNum");
				if (!SO) {
					SO = SOR;
					oModelSO.setProperty("/iptsoNum", SOR);
				}
				var salesorder = SO.substring(0, 10);
				var salesorderitem = SO.substring(10);
				// oFilter[0] = new sap.ui.model.Filter("Serialnumber", sap.ui.model.FilterOperator.EQ, SO);
				oFilter[0] = new sap.ui.model.Filter("Salesordnumber", sap.ui.model.FilterOperator.EQ, salesorder);
				oFilter[1] = new sap.ui.model.Filter("Salesorditem", sap.ui.model.FilterOperator.EQ, salesorderitem);
				// oFilter[0] = new sap.ui.model.Filter("Serialnumber", sap.ui.model.FilterOperator.EQ, SO);
				// oFilter[0] = new sap.ui.model.Filter("Salesordnumber", sap.ui.model.FilterOperator.EQ, SO);
				var oModel = this.getOwnerComponent().getModel();
				oModel.read('/ZCDSV_QM_GRADING', {
					success: jQuery.proxy(this._getVerifi, this),
					filters: oFilter
				});

				var of4FilterCT = new Array();
				of4FilterCT[0] = new sap.ui.model.Filter("Codegruppe", sap.ui.model.FilterOperator.EQ, 'CN-TYPES');

				oModel.read('/ZshInspCatalogSet', {
					success: jQuery.proxy(this._setF4CoinTypes, this),
					filters: of4FilterCT
				});
				var of4FilterCS = new Array();
				of4FilterCS[0] = new sap.ui.model.Filter("Codegruppe", sap.ui.model.FilterOperator.EQ, 'CN-STRIK');

				oModel.read('/ZshInspCatalogSet', {
					success: jQuery.proxy(this._setF4DCS, this),
					filters: of4FilterCS
				});
				var of4FilterGRD = new Array();
				of4FilterGRD[0] = new sap.ui.model.Filter("Codegruppe", sap.ui.model.FilterOperator.EQ, 'CN-GRADE');

				oModel.read('/ZshInspCatalogSet', {
					success: jQuery.proxy(this._setF4GRD, this),
					filters: of4FilterGRD
				});
				var of4FilterSGC = new Array();
				of4FilterSGC[0] = new sap.ui.model.Filter("Codegruppe", sap.ui.model.FilterOperator.EQ, 'CN-GR-ST');

				oModel.read('/ZshInspCatalogSet', {
					success: jQuery.proxy(this._setF4SGC, this),
					filters: of4FilterSGC
				});
				var of4FilterPGC = new Array();
				of4FilterPGC[0] = new sap.ui.model.Filter("Codegruppe", sap.ui.model.FilterOperator.EQ, 'CN-GR-PL');

				oModel.read('/ZshInspCatalogSet', {
					success: jQuery.proxy(this._setF4PGC, this),
					filters: of4FilterPGC
				});
				var of4FilterCSC = new Array();
				of4FilterCSC[0] = new sap.ui.model.Filter("Codegruppe", sap.ui.model.FilterOperator.EQ, 'CN-STR-C');

				oModel.read('/ZshInspCatalogSet', {
					success: jQuery.proxy(this._setF4CSC, this),
					filters: of4FilterCSC
				});
				var of4FilterNoGrd = new Array();
				of4FilterNoGrd[0] = new sap.ui.model.Filter("Codegruppe", sap.ui.model.FilterOperator.EQ, 'NO-GRADE');

				oModel.read('/ZshInspCatalogSet', {
					success: jQuery.proxy(this._setF4NOGRADE, this),
					filters: of4FilterNoGrd
				});
				var of4FilterNGrd = new Array();
				of4FilterNGrd[0] = new sap.ui.model.Filter("Codegruppe", sap.ui.model.FilterOperator.EQ, 'GRADE');

				oModel.read('/ZshInspCatalogSet', {
					success: jQuery.proxy(this._setF4NGrd, this),
					filters: of4FilterNGrd
				});
				var of4FilterPED = new Array();
				of4FilterPED[0] = new sap.ui.model.Filter("Codegruppe", sap.ui.model.FilterOperator.EQ, 'CN-PEDGR');

				oModel.read('/ZshInspCatalogSet', {
					success: jQuery.proxy(this._setF4PED, this),
					filters: of4FilterPED
				});
				var oHead = new oJSON({});
				var oMain = new oJSON({
					Serialnumber: '',
					Salesordnumber: '',
					Salesorditem: '',
					InspectLotnumber: '',
					Plant: '',
					GradeResult: '',
					GCoinType: '',
					GCoinTypeOper: '',
					GCoinStrike: '',
					GCoinStrikeOper: '',
					GCoinGrade: '',
					GCoinGradeOper: '',
					GStarGradeCoin: '',
					GStarGradeCoinOper: '',
					GPlusGradeCoin: '',
					GPlusGradeCoinOper: '',

					GCoinStrikeCharacters: '',
					GCoinStrikeCharsOper: '',
					GSetUsageDecision: '',
					GCodeGroupUD: '',
					GCodeUD: ''

				});
				var oconf = new oJSON({
					showItem1: true,
					showItem2: true
				});
				this.getView().setModel(oconf, "ConfigView");
				this.getView().setModel(oHead, "oHead");
				this.getView().setModel(oMain, "oMain");
				var d = new Date();
				d.setHours("00");
				d.setMinutes("00");
				d.setSeconds("00");
				// var sec = d.getSeconds() + 1;
				// d.setSeconds(sec);
				// //		nsec = nsec + 1;
				this.getView().byId("TP2").setDateValue(d);
			}, this);
		},
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		_getVerifi: function (oData, oResponse) {
			// Header Details
			var oHModel = this.getView().getModel("oHead");
			oHModel.setProperty("/HResults", oData.results);
			oHModel.setProperty("/EnbPrevious", false);
			oHModel.setProperty("/EnbNext", true);
			var oModel = this.getOwnerComponent().getModel();
			var oNextItem = 0;
			var oCurrentItem = 0;
			var oPreviousItem = 0;
			oHModel.setProperty("/PreviousItem", oPreviousItem);
			oHModel.setProperty("/CurrentItem", oCurrentItem);
			oHModel.setProperty("/NextItem", oNextItem);

			var oMainModel = this.getView().getModel("oMain");
			oMainModel.setData(oData.results[0]);

			if (oData.results[0] === undefined) {
				var dialog1 = new Dialog({
					title: 'Error',
					type: 'Message',
					state: 'Error',
					content: new Text({
						text: "Not Ready for Grading"
					}),
					beginButton: new Button({
						text: 'OK',
						press: function () {
							dialog1.close();
							window.history.go(-1);
							// this.oAddApprovercrt.close();
						}
					}),
					afterClose: function () {
						dialog1.destroy();
					}
				});
				dialog1.open();
			}
			if (oData.results[0] !== undefined && oData.results[0].InspectionLotNumber === '0') {
				var dialog = new Dialog({
					title: 'Error',
					type: 'Message',
					state: 'Error',
					content: new Text({
						text: "Not Ready for Grading"
					}),
					beginButton: new Button({
						text: 'OK',
						press: function () {
							dialog.close();
							window.history.go(-1);
							// this.oAddApprovercrt.close();
						}
					}),
					afterClose: function () {
						dialog.destroy();
					}
				});
				dialog.open();
			}

			oHModel.setProperty("/soNum", oData.results[0].Salesordnumber);
			oHModel.setProperty("/soItemNum", oData.results[0].Salesorditem);
			oHModel.setProperty("/collectible", oData.results[0].CollectibleID);
			// oHModel.setProperty("/soNum", oData.results[0].Salesordnumber);
			// oHModel.setProperty("/Material", oData.results[0].Material);
			// oHModel.setProperty("/Customer", oData.results[0].Customer);
			// oHModel.setProperty("/CName", oData.results[0].Name);
			// var streetAdr = oData.results[0].Street + ',' + oData.results[0].pcode;
			// oHModel.setProperty("/CStreet", streetAdr);
			// var CtryAdr = oData.results[0].City + ',' + oData.results[0].State;
			// oHModel.setProperty("/CCtryAdr", CtryAdr);
			// oHModel.setProperty("/CCtry", oData.results[0].Country);
			var oModelVD = this.getOwnerComponent().getModel("oVerifData");
			if (oData.results[0].Salesordnumber !== "") {
				var SO = oData.results[0].Salesordnumber;
				var oFilter = new Array();
				oFilter[0] = new sap.ui.model.Filter("SalesOrder", sap.ui.model.FilterOperator.EQ, SO);
				// oModelVD.read('/zc_qm_verification', {
				// 	success: jQuery.proxy(this._getVerifiIB1, this),
				// 	filters: oFilter

				// });
			}
			var oFilterPI = new Array();
			var oMat = oData.results[0].Material;
			oFilterPI[0] = new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, oMat);

			var oModelPI = this.getOwnerComponent().getModel("oProductImage");
			oModelPI.read('/C_Product', {
				success: jQuery.proxy(this._getProductImage, this),
				filters: oFilterPI
			});
			oHModel.setProperty("/InspectionLotNumber", oData.results[0].InspectLotnumber);
			oHModel.setProperty("/Serialnumber", oData.results[0].Serialnumber);
			// Set header fields-Sharath
			//Changes for Grading app - Sharath
			oHModel.setProperty("/VYear", oData.results[0].SubsmissionYear);
			oHModel.setProperty("/VMint1", oData.results[0].SubmissionMintMark);
			oHModel.setProperty("/VMintDesc", oData.results[0].MaterialName);
			oHModel.setProperty("/VDenomination", oData.results[0].SubmissionDenom);
			oHModel.setProperty("/VDenominationCurrencyType", oData.results[0].SubmissionDetyp);
			oHModel.setProperty("/VPedigree", oData.results[0].SubmissionPedigree);
			oHModel.setProperty("/VCoinStrikeTypes", oData.results[0].SubmissionCoinStrike);
			// oHModel.setProperty("/CGraded", oData.results[0].VInspLotQty);
			oHModel.setProperty("/TCoins", oData.results[0].GCoinQty);
			oHModel.setProperty("/GCoinStrike", oData.results[0].SubmissionCoinStrike);
			oHModel.setProperty("/Title", oData.results[0].SubmissionCoinStrike);
			//Changes for Grading app - Sharath

			var of4FilterGNotes = new Array();
			of4FilterGNotes[0] = new sap.ui.model.Filter("Coinnumber", sap.ui.model.FilterOperator.EQ, oData.results[0].Serialnumber);

			oModel.read('/GraderNotesTextSet', {
				success: jQuery.proxy(this._setGradeNotes, this),
				filters: of4FilterGNotes
			});
			var t = this;
			this.getView().setBusy(false);
			var timer = setInterval(function () {
				// var oHModel = t.getView().getModel("oHead");
				var d = t.getView().byId("TP2").getDateValue();
				// d.setHours("00");
				// d.setMinutes("00");
				var sec = d.getSeconds() + 1;
				d.setSeconds(sec);
				var m = d.getMinutes();
				var s = d.getSeconds();
				m = t.checkTime(m);
				s = t.checkTime(s);
				var oTime = m + ":" + s;
				t.getView().byId("TP6").setText(oTime);
				//		nsec = nsec + 1;
				t.getView().byId("TP2").setDateValue(d);
				// oHModel.setProperty("/Time", d);
			}, 1000);
		},
		checkTime: function (i) {
			if (i < 10) {
				i = "0" + i;
			} // add zero in front of numbers < 10
			return i;
		},

		_getProductImage: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oHead");
			oHModel.setProperty("/oImageURL", oData.results[0].ProductImageURL);
		},
		_setGradeNotes: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oHead");
			if (oData.results.length > 0) {
				oHModel.setProperty("/GradNotes", oData.results[0].Notes);
			}
		},
		_getVerifiIB1: function (oData, oresponse) {
			var oHModel = this.getView().getModel("oHead");
			oHModel.setProperty("/VYear", oData.results[0].VYear);
			oHModel.setProperty("/VMint1", oData.results[0].VMintMark);
			oHModel.setProperty("/VMintDesc", oData.results[0].MaterialName);
			oHModel.setProperty("/VDenomination", oData.results[0].VDenomination);
			oHModel.setProperty("/VDenominationCurrencyType", oData.results[0].VDenominationCurrencyType);
			oHModel.setProperty("/VPedigree", oData.results[0].VPedigree);
			oHModel.setProperty("/VCoinStrikeTypes", oData.results[0].VCoinStrikeTypes);
			oHModel.setProperty("/CGraded", oData.results[0].VInspLotQty);
			oHModel.setProperty("/TCoins", oData.results[0].VInspLotQty);
			oHModel.setProperty("/GCoinStrike", oData.results[0].VCoinStrikeTypes);
			oHModel.setProperty("/Title", oData.results[0].VCoinStrikeTypes);

		},
		_setF4CoinTypes: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oHead");
			oHModel.setProperty("/f4CoinTypes", oData.results);
		},
		_setF4DCS: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oHead");
			oHModel.setProperty("/f4DCS", oData.results);
		},
		_setF4GRD: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oHead");
			oHModel.setProperty("/f4GRD", oData.results);
		},
		_setF4SGC: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oHead");
			oHModel.setProperty("/f4SGC", oData.results);
		},

		// handleF4NoGrade: function () {
		// 	if (!this.onf4NoGhelpdialog) {
		// 		this.onf4NoGhelpdialog = sap.ui.xmlfragment("zcv.zcoin_grading.view.onf4NoGhelpdialog", this);
		// 		this.getView().addDependent(this.onf4NoGhelpdialog);
		// 	}
		// 	this.onf4NoGhelpdialog.open();
		// },
		_setF4PGC: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oHead");
			oHModel.setProperty("/f4PGC", oData.results);
		},
		_setF4CSC: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oHead");
			oHModel.setProperty("/f4CSC", oData.results);
		},
		_setF4NOGRADE: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oHead");
			oHModel.setProperty("/f4NOGRADE", oData.results);
		},
		_setF4NGrd: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oHead");
			oHModel.setProperty("/F4NGRADE", oData.results);
		},
		_setF4PED: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oHead");
			oHModel.setProperty("/f4PED", oData.results);
		},
		handleF4CoinType: function () {
			if (!this.onf4CThelpdialog) {
				this.onf4CThelpdialog = sap.ui.xmlfragment("zcv.zcoin_final_grading.view.onf4CoinTypes", this);
				this.getView().addDependent(this.onf4CThelpdialog);
			}
			this.onf4CThelpdialog.open();
		},
		handleF4CoinStrike: function () {
			if (!this.onf4CShelpdialog) {
				this.onf4CShelpdialog = sap.ui.xmlfragment("zcv.zcoin_final_grading.view.onf4CoinStrikes", this);
				this.getView().addDependent(this.onf4CShelpdialog);
			}
			this.onf4CShelpdialog.open();
		},
		handleF4CoinGrade: function () {
			if (!this.onf4CGhelpdialog) {
				this.onf4CGhelpdialog = sap.ui.xmlfragment("zcv.zcoin_final_grading.view.onf4CoinGrade", this);
				this.getView().addDependent(this.onf4CGhelpdialog);
			}
			this.onf4CGhelpdialog.open();
		},
		handleF4GStarGradeCoin: function () {
			if (!this.onf4SGChelpdialog) {
				this.onf4SGChelpdialog = sap.ui.xmlfragment("zcv.zcoin_final_grading.view.onf4StarGradeCoin", this);
				this.getView().addDependent(this.onf4SGChelpdialog);
			}
			this.onf4SGChelpdialog.open();
		},
		handleF4PlusGradeCoin: function () {
			if (!this.onf4PGChelpdialog) {
				this.onf4PGChelpdialog = sap.ui.xmlfragment("zcv.zcoin_final_grading.view.onf4PlusGradeCoin", this);
				this.getView().addDependent(this.onf4PGChelpdialog);
			}
			this.onf4PGChelpdialog.open();
		},
		handleF4CoinStrikeChar: function () {
			if (!this.onf4CSChelpdialog) {
				this.onf4CSChelpdialog = sap.ui.xmlfragment("zcv.zcoin_final_grading.view.onf4CoinStrikeChar", this);
				this.getView().addDependent(this.onf4CSChelpdialog);
			}
			this.onf4CSChelpdialog.open();
		},
		// handleSelectedPEDCode: function (oEvent) {
		// 	var selectedObjtyp = oEvent.getSource().getBindingContext("oHead").getObject().Code;
		// 	var selectedObjtypText = oEvent.getSource().getBindingContext("oHead").getObject().Kurztext;

		// 	this.getView("ItemBlock1").byId("i1vpedigree").setValue(selectedObjtyp);
		// 	this.byId("i1Tvpedigree").setText(selectedObjtypText);
		// 	// var oModel = this.getView("ItemBlock1").getModel("oHead");
		// 	// oModel.setProperty("/VDenominationCurrencyType", selectedObjtyp);
		// 	// byId("i1vpedigree").setValue(selectedObjtyp);
		// 	var oModel = this.getView().getModel("oMain");
		// 	var oData = oModel.getData();
		// 	oData.VMintMark = selectedObjtyp;
		// 	oModel.setData(oData);
		// 	this.onf4PEDhelpdialog.close();
		// },
		// handleSelectedMMCode: function (oEvent) {
		// 	var selectedObjtyp = oEvent.getSource().getBindingContext("oHead").getObject().Code;
		// 	var selectedObjtypText = oEvent.getSource().getBindingContext("oHead").getObject().Kurztext;

		// 	this.byId("i1vmintmark").setValue(selectedObjtyp);
		// 	this.byId("i1Tvmintmark").setText(selectedObjtypText);
		// 	var oModel = this.getView().getModel("oMain");
		// 	var oData = oModel.getData();
		// 	oData.VMintMark = selectedObjtyp;
		// 	oModel.setData(oData);
		// 	this.getView().setModel(oModel, "oMainD");
		// 	this.onf4MMhelpdialog.close();
		// },
		// handleSelectedCSTCode: function (oEvent) {
		// 	var selectedObjtyp = oEvent.getSource().getBindingContext("oHead").getObject().Code;
		// 	var selectedObjtypText = oEvent.getSource().getBindingContext("oHead").getObject().Kurztext;

		// 	this.byId("i1vcoinstriketypes").setValue(selectedObjtyp);
		// 	this.byId("i1Tvcoinstriketypes").setText(selectedObjtypText);
		// 	var oModel = this.getView().getModel("oMain");
		// 	var oData = oModel.getData();
		// 	oData.VMintMark = selectedObjtyp;
		// 	oModel.setData(oData);
		// 	this.onf4CSThelpdialog.close();
		// },
		handleSelectedCTYP: function (oEvent) {
			var selectedObjtyp = oEvent.getSource().getBindingContext("oHead").getObject().Code;
			var selectedObjtypText = oEvent.getSource().getBindingContext("oHead").getObject().Kurztext;

			this.byId("i1CoinType").setValue(selectedObjtyp);
			this.byId("i1TCoinType").setText(selectedObjtypText);
			// var oModel = this.getView().getModel("oMain");
			// var oData = oModel.getData();
			// oData.VMintMark = selectedObjtyp;
			// oModel.setData(oData);
			this.onf4CThelpdialog.close();
		},
		handleSelectedCG: function (oEvent) {
			var selectedObjtyp = oEvent.getSource().getBindingContext("oHead").getObject().Code;
			var selectedObjtypText = oEvent.getSource().getBindingContext("oHead").getObject().Kurztext;

			this.byId("i1CoinGrade").setValue(selectedObjtyp);
			this.byId("i1TCoinGrade").setText(selectedObjtypText);
			// var oModel = this.getView().getModel("oMain");
			// var oData = oModel.getData();
			// oData.VMintMark = selectedObjtyp;
			// oModel.setData(oData);
			this.onf4CGhelpdialog.close();
		},
		handleCoinGradeClose: function () {
			this.onf4CGhelpdialog.close();
		},
		handleCSCClose: function () {
			this.onf4CSChelpdialog.close();
		},
		handleCSClose: function () {
			this.onf4CShelpdialog.close();
		},
		handleCTClose: function () {
			this.onf4CThelpdialog.close();
		},
		handlePGCClose: function () {

			this.onf4PGChelpdialog.close();
		},
		handleSGCClose: function () {
			this.onf4SGChelpdialog.close();
		},
		handleSelectedCSTRK: function (oEvent) {
			var selectedObjtyp = oEvent.getSource().getBindingContext("oHead").getObject().Code;
			var selectedObjtypText = oEvent.getSource().getBindingContext("oHead").getObject().Kurztext;

			this.byId("i1CoinStrike").setValue(selectedObjtyp);
			this.byId("i1TCoinStrike").setText(selectedObjtypText);
			// var oModel = this.getView().getModel("oMain");
			// var oData = oModel.getData();
			// oData.VMintMark = selectedObjtyp;
			// oModel.setData(oData);
			this.onf4CShelpdialog.close();
		},
		handleSelectedCSTRKCHAR: function (oEvent) {
			var selectedObjtyp = oEvent.getSource().getBindingContext("oHead").getObject().Code;
			var selectedObjtypText = oEvent.getSource().getBindingContext("oHead").getObject().Kurztext;

			this.byId("i1CoinStrikeCharacters").setValue(selectedObjtyp);
			this.byId("i1TCoinStrikeCharacters").setText(selectedObjtypText);
			// var oModel = this.getView().getModel("oMain");
			// var oData = oModel.getData();
			// oData.VMintMark = selectedObjtyp;
			// oModel.setData(oData);
			this.onf4CSChelpdialog.close();
		},
		handleSelectedSGC: function (oEvent) {
			var selectedObjtyp = oEvent.getSource().getBindingContext("oHead").getObject().Code;
			var selectedObjtypText = oEvent.getSource().getBindingContext("oHead").getObject().Kurztext;

			this.byId("i1StarGradeCoin").setValue(selectedObjtyp);
			this.byId("i1TStarGradeCoin").setText(selectedObjtypText);
			// var oModel = this.getView().getModel("oMain");
			// var oData = oModel.getData();
			// oData.VMintMark = selectedObjtyp;
			// oModel.setData(oData);
			this.onf4SGChelpdialog.close();
		},
		handleSelectedPGC: function (oEvent) {
			var selectedObjtyp = oEvent.getSource().getBindingContext("oHead").getObject().Code;
			var selectedObjtypText = oEvent.getSource().getBindingContext("oHead").getObject().Kurztext;

			this.byId("i1PlusGradeCoin").setValue(selectedObjtyp);
			this.byId("i1TPlusGradeCoin").setText(selectedObjtypText);
			// var oModel = this.getView().getModel("oMain");
			// var oData = oModel.getData();
			// oData.VMintMark = selectedObjtyp;
			// oModel.setData(oData);
			this.onf4PGChelpdialog.close();
		},
		onAcptRjct: function (oEvt) {
			var oSel = oEvt.getSource().getSelectedItem().getKey();
			var oModel = this.getView().getModel("oMain");
			var oData = oModel.getData();
			oData.VMintMark = oSel;
			oModel.setData(oData);
			// var oModel = this.getView().getModel("oHead");

			// oModel.setProperty("/oAUsrDesi", oSel);

		},
		onSaveItem1: function () {

			var oModel1 = this.getView().getModel("oMain");
			var oModel2 = this.getView().getModel("oHead");

			var oInspData = oModel1.getData("oInspData");
			var oInspData_Inp = oModel2.getData();
			// oInspData.VSetUsageDecision = 'A';
			// // var oUsageDec = this.getView("ItemBlock1").byId("vpselAcptRjct").getValue();
			// // if (oUsageDec === '') {
			// // 	var msg = "Please Select User Decision";
			// // 	MessageToast.show(msg);
			// // } else {
			// oInspData.VYear = oInspData_Inp.VYear;
			// oInspData.VMintMark = oInspData_Inp.VMintMark;
			// oInspData.VDenomination = oInspData_Inp.VDenomination;
			// oInspData.VDenominationCurrencyType = oInspData_Inp.VDenominationCurrencyType;
			// oInspData.VPedigree = oInspData_Inp.VPedigree;
			// oInspData.VCoinStrikeTypes = oInspData_Inp.VCoinStrikeTypes;

			// oInspData.VCodeGroupUD = '01';
			// oInspData.VCodeUD = '01';

			oInspData.GCoinType = oInspData_Inp.GCoinType;
			oInspData.GCoinGrade = oInspData_Inp.GCoinGrade;
			oInspData.GPlusGradeCoin = oInspData_Inp.GPlusGradeCoin;
			oInspData.GCoinStrike = oInspData_Inp.GCoinStrike;
			oInspData.GStarGradeCoin = oInspData_Inp.GStarGradeCoin;
			oInspData.GCoinStrikeCharacters = oInspData_Inp.GCoinStrikeCharacters;

			oInspData.GSetUsageDecision = 'A';
			oInspData.GCodeGroupUD = '01';
			oInspData.GCodeUD = '01';

			var oModel = this.getOwnerComponent().getModel();
			oModel.create("/ZCDSV_QM_GRADING", oInspData, {
				success: jQuery.proxy(this._handleVerfSaveData, this)
			});
			// }
		},
		onDsplyResults: function () {},
		_handleVerfSaveData: function (oData, oResponse) {

			this.getView().getModel().refresh();
			var dialog = new Dialog({
				title: 'Success',
				type: 'Message',
				state: 'Success',
				content: new Text({
					text: 'Grading Results Updated Successfully'
				}),
				beginButton: new Button({
					text: 'OK',
					press: function () {
						dialog.close();
						// window.history.go(-1);
						// this.oAddApprovercrt.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
		},
		handleSGCSearch: function (oEvnt) {
			var oModel = this.getOwnerComponent().getModel();
			var oFilter = new Array();
			var scode = this.getOwnerComponent().getModel("oMainModel").getProperty("/f4SGCcode");
			oFilter[0] = new sap.ui.model.Filter("Code", sap.ui.model.FilterOperator.EQ, scode);
			// oFilter[1] = new sap.ui.model.Filter("Code", sap.ui.model.FilterOperator.EQ, scode);
			oModel.read("/ZshInspCatalogSet", {
				success: jQuery.proxy(this._setF4SGC, this),
				filters: oFilter

			});
		},
		onNavBack: function () {
			window.history.go(-1);
		},
		onPrevious: function (oEvent) {
			var oHModel = this.getView().getModel("oHead");
			oHModel.setProperty("/EnbPrevious", true);
			oHModel.setProperty("/EnbNext", true);
			var oHResults = oHModel.getProperty("/HResults");

			var oNextItem = oHModel.getProperty("/NextItem");
			oNextItem = oNextItem - 1;

			var oPreviousItem = oHModel.getProperty("/PreviousItem");
			oPreviousItem = oPreviousItem - 1;

			var oCurrentItem = oHModel.getProperty("/CurrentItem");
			oCurrentItem = oPreviousItem;

			if (oCurrentItem === 0) {
				oHModel.setProperty("/EnbPrevious", false);
			}
			oHModel.setProperty("/PreviousItem", oPreviousItem);
			oHModel.setProperty("/CurrentItem", oCurrentItem);
			oHModel.setProperty("/NextItem", oNextItem);

			oHModel.setProperty("/InspectionLotNumber", oHResults[oCurrentItem].InspectLotnumber);
			oHModel.setProperty("/Serialnumber", oHResults[oCurrentItem].Serialnumber);
			var of4FilterGNotes = new Array();
			of4FilterGNotes[0] = new sap.ui.model.Filter("Coinnumber", sap.ui.model.FilterOperator.EQ, oHResults[oCurrentItem].Serialnumber);
			var oModel = this.getOwnerComponent().getModel();
			oModel.read('/GraderNotesTextSet', {
				success: jQuery.proxy(this._setGradeNotes, this),
				filters: of4FilterGNotes
			});
			// this.getView().refresh();
			if (oHResults[oCurrentItem].GSetUsageDecision !== "") {
				oHModel.setProperty("/visFld", false);

				oHModel.setProperty("/GCoinType", oHResults[oCurrentItem].GCoinType);
				oHModel.setProperty("/GCoinStrike", oHResults[oCurrentItem].GCoinStrike);
				oHModel.setProperty("/GCoinGrade", oHResults[oCurrentItem].GCoinGrade);
				oHModel.setProperty("/GStarGradeCoin", oHResults[oCurrentItem].GStarGradeCoin);
				oHModel.setProperty("/GPlusGradeCoin", oHResults[oCurrentItem].GPlusGradeCoin);
				oHModel.setProperty("/GCoinStrikeCharacters", oHResults[oCurrentItem].GCoinStrikeCharacters);
				oHModel.setProperty("/GTimeSpent", oHResults[oCurrentItem].GTimeSpent);
			} else {
				oHModel.setProperty("/GCoinType", " ");
				// oHModel.setProperty("/GCoinStrike", "");
				oHModel.setProperty("/GCoinGrade", " ");
				oHModel.setProperty("/GNumGrade", " ");
				oHModel.setProperty("/GStarGradeCoin", " ");
				oHModel.setProperty("/GPlusGradeCoin", " ");
				oHModel.setProperty("/GCoinStrikeCharacters", " ");
				oHModel.setProperty("/GTimeSpent", " ");
				oHModel.setProperty("/Text", "");
				oHModel.setProperty("/Text1", "");
				oHModel.setProperty("/Text2", "");
				oHModel.setProperty("/Text3", "");
				oHModel.setProperty("/Text4", "");
				oHModel.setProperty("/Text5", "");
				oHModel.setProperty("/Text6", "");
				oHModel.setProperty("/Text7", "");

				oHModel.setProperty("/visFld", true);
			}

		},
		onNext: function (oEvent) {
			var oHModel = this.getView().getModel("oHead");
			oHModel.setProperty("/EnbPrevious", true);
			oHModel.setProperty("/EnbNext", true);
			var oHResults = oHModel.getProperty("/HResults");

			var oNextItem = oHModel.getProperty("/NextItem");
			oNextItem = oNextItem + 1;

			var oCurrentItem = oHModel.getProperty("/CurrentItem");
			oCurrentItem = oNextItem;

			var oPreviousItem = oHModel.getProperty("/PreviousItem");
			oPreviousItem = oPreviousItem + 1;
			oHModel.setProperty("/PreviousItem", oPreviousItem);
			oHModel.setProperty("/CurrentItem", oCurrentItem);
			oHModel.setProperty("/NextItem", oNextItem);
			var olen = oHResults.length - 1;
			if (olen === oNextItem) {
				oHModel.setProperty("/EnbNext", false);
			}

			oHModel.setProperty("/InspectionLotNumber", oHResults[oCurrentItem].InspectLotnumber);
			oHModel.setProperty("/Serialnumber", oHResults[oCurrentItem].Serialnumber);
			var of4FilterGNotes = new Array();
			of4FilterGNotes[0] = new sap.ui.model.Filter("Coinnumber", sap.ui.model.FilterOperator.EQ, oHResults[oCurrentItem].Serialnumber);
			var oModel = this.getOwnerComponent().getModel();
			oModel.read('/GraderNotesTextSet', {
				success: jQuery.proxy(this._setGradeNotes, this),
				filters: of4FilterGNotes
			});
			// this.getView().refresh();
			// var oHModel = this.getView().getModel("oHead");
			// var oMainModel = this.getView().getModel("oMain");
			if (oHResults[oCurrentItem].GSetUsageDecision !== "") {
				oHModel.setProperty("/visFld", false);

				oHModel.setProperty("/GCoinType", oHResults[oCurrentItem].GCoinType);
				oHModel.setProperty("/GCoinStrike", oHResults[oCurrentItem].GCoinStrike);
				oHModel.setProperty("/GCoinGrade", oHResults[oCurrentItem].GCoinGrade);
				oHModel.setProperty("/GStarGradeCoin", oHResults[oCurrentItem].GStarGradeCoin);
				oHModel.setProperty("/GPlusGradeCoin", oHResults[oCurrentItem].GPlusGradeCoin);
				oHModel.setProperty("/GCoinStrikeCharacters", oHResults[oCurrentItem].GCoinStrikeCharacters);
				oHModel.setProperty("/GTimeSpent", oHResults[oCurrentItem].GTimeSpent);
			} else {
				oHModel.setProperty("/GCoinType", "");
				// oHModel.setProperty("/GCoinStrike", "");
				oHModel.setProperty("/GCoinGrade", "");
				oHModel.setProperty("/GNumGrade", "");
				oHModel.setProperty("/GStarGradeCoin", "");
				oHModel.setProperty("/GPlusGradeCoin", "");
				oHModel.setProperty("/GCoinStrikeCharacters", "");
				oHModel.setProperty("/GTimeSpent", "");
				oHModel.setProperty("/visFld", true);
				oHModel.setProperty("/Text", "");
				oHModel.setProperty("/Text1", "");
				oHModel.setProperty("/Text2", "");
				oHModel.setProperty("/Text3", "");
				oHModel.setProperty("/Text4", "");
				oHModel.setProperty("/Text5", "");
				oHModel.setProperty("/Text6", "");
				oHModel.setProperty("/Text7", "");

			}

		},
		onCoinHistory: function (oEvent) {
			this.oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");

			this.oCrossAppNav.toExternal({
				target: {
					semanticObject: "Equipment",
					action: "GradingHistory"
				}

			});
		},
		handleSOPress: function (oEvent) {
			var oModelSO = this.getOwnerComponent().getModel("oMainModel");
			// var SO = oModelSO.getProperty("/iptsoNum");
			var SO = oModelSO.getProperty("/iptsoNum");
			var salesorder = SO.substring(0, 10);

			this.oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");

			this.oCrossAppNav.toExternal({
				target: {
					semanticObject: "SalesOrder",
					action: "displayFactSheet"
				},
				params: {
					SalesOrder: salesorder
				}
			});
		},
		handleCollectiblePress: function (oEvent) {

			// var oCollectible = oEvent.getSource().getText();
			var oCollectible = this.getView().byId("Collectible").getText();
			// var salesorder = SO.substring(0, 10);
			var oCoinNumber = oCollectible;
			while (oCoinNumber.length < 18) {
				oCoinNumber = "0" + oCoinNumber;
			}
			this.oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");

			this.oCrossAppNav.toExternal({
				target: {
					semanticObject: "MaintenanceObject",
					action: "displayFactSheet"
				},
				params: {
					TechObjIsEquipOrFuncnlLoc: "EAMS_EQUI",
					TechnicalObject: oCoinNumber
				}

			});

		}

	});
});