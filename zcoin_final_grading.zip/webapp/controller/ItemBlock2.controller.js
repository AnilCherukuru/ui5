sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/ui/core/format/DateFormat"
], function (Controller, DateFormat) {
	"use strict";
	return Controller.extend("zcv.zcoin_final_grading.blocks.ItemBlock1", {
		onInit: function () {
			var oDateFormat = DateFormat.getDateInstance({
				source: {
					pattern: "timestamp"
				},
				pattern: "dd/MM/yyyy"
			});
			var oModel = this.getOwnerComponent().getModel("oGradResults");
			var oFilter = new Array();
			var oModelSO = this.getOwnerComponent().getModel("oMainModel");
			// var SO = oModelSO.getProperty("/iptsoNum");
			var SO = oModelSO.getProperty("/iptsoNum");
			var salesorder = SO.substring(0, 10);
			var salesorderitem = SO.substring(10);
			// oFilter[0] = new sap.ui.model.Filter("SerialNumber", sap.ui.model.FilterOperator.EQ, SO);
			oFilter[0] = new sap.ui.model.Filter("SalesOrder", sap.ui.model.FilterOperator.EQ, salesorder);
			oFilter[1] = new sap.ui.model.Filter("SalesOrderItem", sap.ui.model.FilterOperator.EQ, salesorderitem);

			oModel.read("/ZCDSV_GRADING_RESULTS", {
				success: jQuery.proxy(this._setGradResults, this),
				filters: oFilter
			});
		},
		_setGradResults: function (oData, oResults) {
			var oModelSO = this.getOwnerComponent().getModel("oMainModel");
			var oDateFormat = DateFormat.getDateInstance({
				source: {
					pattern: "timestamp"
				},
				pattern: "MM/dd/yyyy"
			});
			var oTimeFormat = DateFormat.getTimeInstance({
				source: {
					pattern: "timestamp"
				},
				pattern: "HH:MM:SS"
			});
			for (var i = 0; i < oData.results.length; i++) {
				var oProduct = oData.results[i];
				oProduct.UserDate1 = oDateFormat.format(new Date(oProduct.UserDate1));
				oProduct.UserTime1 = oTimeFormat.format(new Date(oProduct.UserTime1.ms));
			}
			// this.oFormatDdmmyyyy.format(oData.results[0].UserDate1);

			oModelSO.setProperty("/oGradRslts", oData.results);
		},
		onNavBack: function () {
			window.history.go(-1);
		}

	});
});