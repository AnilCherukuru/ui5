sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/Text"
], function (Controller, oJSON, MessageToast, Dialog, Button, Text) {
	"use strict";
	return Controller.extend("zcv.zcoin_final_grading.blocks.ItemBlock1", {
		onInit: function () {
			var oModel = this.getOwnerComponent().getModel();
			var oFilter = new Array();
			var oModelSO = this.getOwnerComponent().getModel("oMainModel");
			var SO = oModelSO.getProperty("/iptsoNum");
			var salesorder = SO.substring(0, 10);
			var salesorderitem = SO.substring(10);
			// var SO = oModelSO.getProperty("/iptsoNum");
			oFilter[0] = new sap.ui.model.Filter("Salesordnumber", sap.ui.model.FilterOperator.EQ, salesorder);
			oFilter[1] = new sap.ui.model.Filter("Salesorditem", sap.ui.model.FilterOperator.EQ, salesorderitem);
			// oFilter[0] = new sap.ui.model.Filter("Serialnumber", sap.ui.model.FilterOperator.EQ, SO);
			oModel.read('/ZCDSV_QM_GRADING', {
				success: jQuery.proxy(this._getVerifiIB, this),
				filters: oFilter
			});
			var of4FilterCT = new Array();
			of4FilterCT[0] = new sap.ui.model.Filter("Codegruppe", sap.ui.model.FilterOperator.EQ, 'CN-TYPES');

			oModel.read('/ZshInspCatalogSet', {
				success: jQuery.proxy(this._setF4CoinTypes, this),
				filters: of4FilterCT
			});
			var of4FilterCS = new Array();
			of4FilterCS[0] = new sap.ui.model.Filter("Codegruppe", sap.ui.model.FilterOperator.EQ, 'CN-STRIK');

			oModel.read('/ZshInspCatalogSet', {
				success: jQuery.proxy(this._setF4DCS, this),
				filters: of4FilterCS
			});
			var of4FilterGRD = new Array();
			of4FilterGRD[0] = new sap.ui.model.Filter("Codegruppe", sap.ui.model.FilterOperator.EQ, 'CN-GRADE');

			oModel.read('/ZshInspCatalogSet', {
				success: jQuery.proxy(this._setF4GRD, this),
				filters: of4FilterGRD
			});
			var of4FilterSGC = new Array();
			of4FilterSGC[0] = new sap.ui.model.Filter("Codegruppe", sap.ui.model.FilterOperator.EQ, 'CN-GR-ST');

			oModel.read('/ZshInspCatalogSet', {
				success: jQuery.proxy(this._setF4SGC, this),
				filters: of4FilterSGC
			});
			var of4FilterPGC = new Array();
			of4FilterPGC[0] = new sap.ui.model.Filter("Codegruppe", sap.ui.model.FilterOperator.EQ, 'CN-GR-PL');

			oModel.read('/ZshInspCatalogSet', {
				success: jQuery.proxy(this._setF4PGC, this),
				filters: of4FilterPGC
			});
			var of4FilterCSC = new Array();
			of4FilterCSC[0] = new sap.ui.model.Filter("Codegruppe", sap.ui.model.FilterOperator.EQ, 'CN-STR-C');

			oModel.read('/ZshInspCatalogSet', {
				success: jQuery.proxy(this._setF4CSC, this),
				filters: of4FilterCSC
			});
			var of4FilterNGrd = new Array();
			of4FilterNGrd[0] = new sap.ui.model.Filter("Codegruppe", sap.ui.model.FilterOperator.EQ, 'GRADE');

			oModel.read('/ZshInspCatalogSet', {
				success: jQuery.proxy(this._setF4NGrd, this),
				filters: of4FilterNGrd
			});
		},
		_getVerifiIB: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oHead");
			// var oMainModel = this.getView().getModel("oMain");
			var oLen = 0;
			if (!oData.results[0].GSetUsageDecision) {
				if (oData.results[0].GSetUsageDecision !== "") {
					oHModel.setProperty("/visFld", false);

					oHModel.setProperty("/GCoinType", oData.results[oLen].GCoinType);
					// oHModel.setProperty("/GCoinStrike", oData.results[oLen].GCoinStrike);

					oHModel.setProperty("/GCoinNoGrade", oData.results[0].GCoinNoGrade);
					oHModel.setProperty("/GCoinStrike", oData.results[oLen].SubmissionCoinStrike);
					oHModel.setProperty("/GCoinGrade", oData.results[oLen].GCoinGrade);
					oHModel.setProperty("/GStarGradeCoin", oData.results[oLen].GStarGradeCoin);
					oHModel.setProperty("/GPlusGradeCoin", oData.results[oLen].GPlusGradeCoin);
					oHModel.setProperty("/GCoinStrikeCharacters", oData.results[oLen].GCoinStrikeCharacters);
					oHModel.setProperty("/GTimeSpent", oData.results[oLen].GTimeSpent);
				} else {
					oHModel.setProperty("/GCoinType", "");
					oHModel.setProperty("/GCoinStrike", "");
					oHModel.setProperty("/GCoinGrade", "");
					oHModel.setProperty("/GCoinNoGrade", "");
					oHModel.setProperty("/GStarGradeCoin", " ");
					oHModel.setProperty("/GPlusGradeCoin", " ");
					oHModel.setProperty("/GCoinStrikeCharacters", " ");
					oHModel.setProperty("/GTimeSpent", " ");
					oHModel.setProperty("/visFld", true);
				}
			}
		},
		handleF4MintMark: function () {
			if (!this.onf4MMhelpdialog) {
				this.onf4MMhelpdialog = sap.ui.xmlfragment("zcv.zcoin_final_grading.view.onf4MintMark", this);
				this.getView().addDependent(this.onf4MMhelpdialog);
			}
			this.onf4MMhelpdialog.open();
		},
		_setF4CoinTypes: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oHead");
			oHModel.setProperty("/f4CoinTypes", oData.results);
		},
		_setF4DCS: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oHead");
			oHModel.setProperty("/f4DCS", oData.results);
		},
		_setF4GRD: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oHead");
			oHModel.setProperty("/f4GRD", oData.results);
		},
		_setF4SGC: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oHead");
			oHModel.setProperty("/f4SGC", oData.results);
		},
		_setF4PGC: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oHead");
			oHModel.setProperty("/f4PGC", oData.results);
		},
		_setF4CSC: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oHead");
			oHModel.setProperty("/f4CSC", oData.results);
		},
		_setF4NGrd: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oHead");
			oHModel.setProperty("/F4NGRADE", oData.results);
		},
		handleSearchDG: function (oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var oModelH = this.getView().getModel("oHead");
			var oCode = oModelH.getProperty("/f4code");
			var of4FilterGRD = new Array();
			of4FilterGRD[0] = new sap.ui.model.Filter("Codegruppe", sap.ui.model.FilterOperator.EQ, 'CN-GRADE');
			of4FilterGRD[1] = new sap.ui.model.Filter("Code", sap.ui.model.FilterOperator.Contains, oCode);

			oModel.read('/ZshInspCatalogSet', {
				success: jQuery.proxy(this._setF4GRD, this),
				filters: of4FilterGRD
			});

			// var oYear = oModelH.getProperty("/f4Year");	
		},

		handleF4PED: function () {
			if (!this.onf4PEDhelpdialog) {
				this.onf4PEDhelpdialog = sap.ui.xmlfragment("zcv.zcoin_final_grading.view.onf4Pedigree", this);
				this.getView().addDependent(this.onf4PEDhelpdialog);
			}
			this.onf4PEDhelpdialog.open();
		},
		handleF4PED2: function () {
			if (!this.onf4PED2helpdialog) {
				this.onf4PED2helpdialog = sap.ui.xmlfragment("zcv.zcoin_final_grading.view.onf4Pedigree2", this);
				this.getView().addDependent(this.onf4PED2helpdialog);
			}
			this.onf4PED2helpdialog.open();
		},

		handleF4CoinType: function () {
			if (!this.onf4CThelpdialog) {
				this.onf4CThelpdialog = sap.ui.xmlfragment("zcv.zcoin_final_grading.view.onf4CoinTypes", this);
				this.getView().addDependent(this.onf4CThelpdialog);
			}
			this.onf4CThelpdialog.open();
		},
		handleF4NGrade: function () {
			if (!this.onf4NGrhelpdialog) {
				this.onf4NGrhelpdialog = sap.ui.xmlfragment("zcv.zcoin_final_grading.view.onf4NumGrade", this);
				this.getView().addDependent(this.onf4NGrhelpdialog);
			}
			this.onf4NGrhelpdialog.open();
		},
		handleF4CoinStrike: function () {
			if (!this.onf4CShelpdialog) {
				this.onf4CShelpdialog = sap.ui.xmlfragment("zcv.zcoin_final_grading.view.onf4CoinStrikes", this);
				this.getView().addDependent(this.onf4CShelpdialog);
			}
			this.onf4CShelpdialog.open();
		},
		handleF4CoinGrade: function () {
			if (!this.onf4CGhelpdialog) {
				this.onf4CGhelpdialog = sap.ui.xmlfragment("zcv.zcoin_final_grading.view.onf4CoinGrade", this);
				this.getView().addDependent(this.onf4CGhelpdialog);
			}
			this.onf4CGhelpdialog.open();
		},
		handleF4GStarGradeCoin: function () {
			if (!this.onf4SGChelpdialog) {
				this.onf4SGChelpdialog = sap.ui.xmlfragment("zcv.zcoin_final_grading.view.onf4StarGradeCoin", this);
				this.getView().addDependent(this.onf4SGChelpdialog);
			}
			this.onf4SGChelpdialog.open();
		},
		handleSelectedNG: function (oEvent) {
			var selectedObjtyp = oEvent.getSource().getBindingContext("oHead").getObject().Code;
			var selectedObjtypText = oEvent.getSource().getBindingContext("oHead").getObject().Kurztext;

			this.byId("i1PlusNoGrade").setValue(selectedObjtyp);
			this.byId("i1TPlusNoGrade").setText(selectedObjtypText);
			// var oModel = this.getView().getModel("oMain");
			// var oData = oModel.getData();
			// oData.VMintMark = selectedObjtyp;
			// oModel.setData(oData);
			this.onf4NoGhelpdialog.close();
		},
		handleSelectedNGrade: function (oEvent) {
			var selectedObjtyp = oEvent.getSource().getBindingContext("oHead").getObject().Code;
			var selectedObjtypText = oEvent.getSource().getBindingContext("oHead").getObject().Kurztext;

			this.byId("i1FGrade").setValue(selectedObjtyp);
			this.byId("i1TFGrade").setText(selectedObjtypText);
			var oModel = this.getView().getModel("oHead");
			var CS = oModel.getProperty("/VCoinStrikeTypes");
			var grade = selectedObjtyp;
			var ngrade = Math.trunc(grade);
			var oTitle = CS + ngrade;
			oModel.setProperty("/Title", oTitle);
			oModel.setProperty("/GCoinGrade", oTitle);
			// var oModel = this.getView().getModel("oHead");
			// // var oGradeIptV = this.getView().byId('i1Grade').getValue();
			// var oTitle = selectedObjtypText;
			// oModel.setProperty("/Title", oTitle);
			// // var oModel = this.getView().getModel("oMain");
			// // var oData = oModel.getData();
			// // oData.VMintMark = selectedObjtyp;
			// // oModel.setData(oData);
			this.onf4NGrhelpdialog.close();
		},
		handleF4PlusGradeCoin: function () {
			if (!this.onf4PGChelpdialog) {
				this.onf4PGChelpdialog = sap.ui.xmlfragment("zcv.zcoin_final_grading.view.onf4PlusGradeCoin", this);
				this.getView().addDependent(this.onf4PGChelpdialog);
			}
			this.onf4PGChelpdialog.open();
		},
		handleF4CoinStrikeChar: function () {
			if (!this.onf4CSChelpdialog) {
				this.onf4CSChelpdialog = sap.ui.xmlfragment("zcv.zcoin_final_grading.view.onf4CoinStrikeChar", this);
				this.getView().addDependent(this.onf4CSChelpdialog);
			}
			this.onf4CSChelpdialog.open();
		},
		handleSelectedCTYP: function (oEvent) {
			var selectedObjtyp = oEvent.getSource().getBindingContext("oHead").getObject().Code;
			var selectedObjtypText = oEvent.getSource().getBindingContext("oHead").getObject().Kurztext;

			this.byId("i1CoinType").setValue(selectedObjtyp);
			this.byId("i1TCoinType").setText(selectedObjtypText);
			// var oModel = this.getView().getModel("oMain");
			// var oData = oModel.getData();
			// oData.VMintMark = selectedObjtyp;
			// oModel.setData(oData);
			this.onf4CThelpdialog.close();
		},
		handleSelectedCG: function (oEvent) {
			var selectedObjtyp = oEvent.getSource().getBindingContext("oHead").getObject().Code;
			var selectedObjtypText = oEvent.getSource().getBindingContext("oHead").getObject().Kurztext;

			this.byId("i1CoinGrade").setValue(selectedObjtyp);
			this.byId("i1TCoinGrade").setText(selectedObjtypText);
			// var oModel = this.getView().getModel("oMain");
			// var oData = oModel.getData();
			// oData.VMintMark = selectedObjtyp;
			// oModel.setData(oData);
			// var oModel = this.getView().getModel("oHead");
			// var oGradeIptV = this.getView().byId('i1Grade').getValue();
			// var oTitle = selectedObjtypText;
			// oModel.setProperty("/Title", oTitle);
			this.onf4CGhelpdialog.close();
		},
		handleCoinGradeClose: function () {
			this.onf4CGhelpdialog.close();
		},
		handleCSCClose: function () {
			this.onf4CSChelpdialog.close();
		},
		handleCSClose: function () {
			this.onf4CShelpdialog.close();
		},
		handleCTClose: function () {
			this.onf4CThelpdialog.close();
		},
		handlePGCClose: function () {

			this.onf4PGChelpdialog.close();
		},
		handleSGCClose: function () {
			this.onf4SGChelpdialog.close();
		},
		handleSelectedCSTRK: function (oEvent) {
			var selectedObjtyp = oEvent.getSource().getBindingContext("oHead").getObject().Code;
			var selectedObjtypText = oEvent.getSource().getBindingContext("oHead").getObject().Kurztext;

			this.byId("i1CoinStrike").setValue(selectedObjtyp);
			this.byId("i1TCoinStrike").setText(selectedObjtypText);
			// var oModel = this.getView().getModel("oMain");
			// var oData = oModel.getData();
			// oData.VMintMark = selectedObjtyp;
			// oModel.setData(oData);
			this.onf4CShelpdialog.close();
		},
		handleSelectedCSTRKCHAR: function (oEvent) {
			var selectedObjtyp = oEvent.getSource().getBindingContext("oHead").getObject().Code;
			var selectedObjtypText = oEvent.getSource().getBindingContext("oHead").getObject().Kurztext;

			this.byId("i1CoinStrikeCharacters").setValue(selectedObjtyp);
			this.byId("i1TCoinStrikeCharacters").setText(selectedObjtypText);
			// var oModel = this.getView().getModel("oMain");
			// var oData = oModel.getData();
			// oData.VMintMark = selectedObjtyp;
			// oModel.setData(oData);
			this.onf4CSChelpdialog.close();
		},
		handleSelectedSGC: function (oEvent) {
			var selectedObjtyp = oEvent.getSource().getBindingContext("oHead").getObject().Code;
			var selectedObjtypText = oEvent.getSource().getBindingContext("oHead").getObject().Kurztext;

			this.byId("i1StarGradeCoin").setValue(selectedObjtyp);
			this.byId("i1TStarGradeCoin").setText(selectedObjtypText);
			// var oModel = this.getView().getModel("oMain");
			// var oData = oModel.getData();
			// oData.VMintMark = selectedObjtyp;
			// oModel.setData(oData);
			this.onf4SGChelpdialog.close();
		},
		handleSelectedPGC: function (oEvent) {
			var selectedObjtyp = oEvent.getSource().getBindingContext("oHead").getObject().Code;
			var selectedObjtypText = oEvent.getSource().getBindingContext("oHead").getObject().Kurztext;

			this.byId("i1PlusGradeCoin").setValue(selectedObjtyp);
			this.byId("i1TPlusGradeCoin").setText(selectedObjtypText);
			// var oModel = this.getView().getModel("oMain");
			// var oData = oModel.getData();
			// oData.VMintMark = selectedObjtyp;
			// oModel.setData(oData);
			this.onf4PGChelpdialog.close();
		},
		handleSelectedPED2Code: function (oEvent) {
			var selectedObjtyp = oEvent.getSource().getBindingContext("oHead").getObject().Code;
			// var selectedObjtypText = oEvent.getSource().getBindingContext("oHead").getObject().Kurztext;
			this.byId("i1Pedigree2").setValue(selectedObjtyp);
			// this.byId("tai1Pedigree2").setValue(selectedObjtypText);
			this.onf4PED2helpdialog.close();
		},
		handleSelectedPEDCode: function (oEvent) {
			var selectedObjtyp = oEvent.getSource().getBindingContext("oHead").getObject().Code;
			// var selectedObjtypText = oEvent.getSource().getBindingContext("oHead").getObject().Kurztext;
			this.byId("i1pedigree").setValue(selectedObjtyp);
			// this.byId("tAi1Pedigree").setValue(selectedObjtypText);
			this.onf4PEDhelpdialog.close();
		},
		onSaveItem1: function () {
			this.getView().setBusy(true);
			var oModel1 = this.getView().getModel("oMain");
			var oModel2 = this.getView().getModel("oHead");
			var oCurrentItem = oModel2.getProperty("/CurrentItem");
			var oCurItem = oModel2.getProperty("/HResults")[oCurrentItem];
			var oInspData = oModel1.getData("oInspData");
			var oInspData_Inp = oModel2.getData();
			// oInspData.VSetUsageDecision = 'A';
			// // var oUsageDec = this.getView("ItemBlock1").byId("vpselAcptRjct").getValue();
			// // if (oUsageDec === '') {
			// // 	var msg = "Please Select User Decision";
			// // 	MessageToast.show(msg);
			// // } else {
			// oInspData.VYear = oInspData_Inp.VYear;
			// oInspData.VMintMark = oInspData_Inp.VMintMark;
			// oInspData.VDenomination = oInspData_Inp.VDenomination;
			// oInspData.VDenominationCurrencyType = oInspData_Inp.VDenominationCurrencyType;
			// oInspData.VPedigree = oInspData_Inp.VPedigree;
			// oInspData.VCoinStrikeTypes = oInspData_Inp.VCoinStrikeTypes;

			// oInspData.VCodeGroupUD = '01';
			// oInspData.VCodeUD = '01';
			oInspData.Serialnumber = oCurItem.Serialnumber;
			oInspData.InspectLotnumber = oCurItem.InspectLotnumber;
			oInspData.GCoinType = oInspData_Inp.GCoinType;
			oInspData.GCoinGrade = oInspData_Inp.GCoinGrade;
			oInspData.GCoinNumGrade = oInspData_Inp.GNumGrade;
			// oInspData.GPlusGradeCoin = oInspData_Inp.GPlusGradeCoin;
			// oInspData.GCoinStrike = oInspData_Inp.GCoinStrike;
			oInspData.GCoinStrike = oInspData.SubmissionCoinStrike;
			oInspData.GCoinNoGrade = oInspData_Inp.GCoinNoGrade;
			// oInspData.GStarGradeCoin = oInspData_Inp.GStarGradeCoin;
			oInspData.GCoinStrikeCharacters = oInspData_Inp.GCoinStrikeCharacters;
			oInspData.GraderNotesText = oModel2.getProperty("/GText");
			oInspData.GCoinPedigree = oModel2.getProperty("/VPedigree");
			oInspData.GCoinPedigree2 = oModel2.getProperty("/VPedigree2");
			oInspData.GCoinPedigreeStext = oModel2.getProperty("/pedgreeNotes");
			oInspData.GCoinPedigree2Stext = oModel2.getProperty("/pedgree2Notes");
			// var CS = oInspData.GCoinStrike;
			var CS = oInspData.SubmissionCoinStrike;
			var grade = oInspData.GCoinNumGrade;
			var ngrade = Math.trunc(grade);
			var oStrPlus = CS + ngrade;
			// var oStrPlus = oInspData.SubmissionCoinStrike + ngrade;
			oInspData.GPlusGradeCoin = '';
			oInspData.GStarGradeCoin = '';
			if (oInspData_Inp.GPlusGradeCoin === "X") {
				oInspData.GPlusGradeCoin = oStrPlus;
			}
			if (oInspData_Inp.GStarGradeCoin === "X") {
				oInspData.GStarGradeCoin = oStrPlus;
			}
			oInspData.GSetUsageDecision = 'A';
			oInspData.GCodeGroupUD = '01';
			oInspData.GCodeUD = '01';

			var oModel = this.getOwnerComponent().getModel();
			oModel.create("/ZCDSV_QM_GRADING", oInspData, {
				success: jQuery.proxy(this._handleVerfSaveData, this)
			});
			// }
		},
		onDsplyResults: function () {},
		handleF4NoGrade: function () {
			if (!this.onf4NoGhelpdialog) {
				this.onf4NoGhelpdialog = sap.ui.xmlfragment("zcv.zcoin_final_grading.view.onf4NoGhelpdialog", this);
				this.getView().addDependent(this.onf4NoGhelpdialog);
			}
			this.onf4NoGhelpdialog.open();
		},

		_handleVerfSaveData: function (oData, oResponse) {
			this.getView().setBusy(false);
			this.getView().getModel().refresh();

			var oErrRes = oResponse.headers["sap-message"];
			var oErrMsg = JSON.parse(oErrRes);
			var oErrTyp = oErrMsg.severity;

			if (oErrTyp === "error") {
				var oDErrTyp = "Error";
				var oDErrMsg = oErrMsg.message;
			} else {
				oDErrTyp = "Success";
				oDErrMsg = "Final Grading Process Completed";
			}

			var oHModel = this.getView().getModel("oHead");
			oHModel.setProperty("/EnbPrevious", true);
			oHModel.setProperty("/EnbNext", true);
			var oHResults = oHModel.getProperty("/HResults");

			var oNextItem = oHModel.getProperty("/NextItem");
			oNextItem = oNextItem + 1;

			var oCurrentItem = oHModel.getProperty("/CurrentItem");
			oCurrentItem = oNextItem;

			var oPreviousItem = oHModel.getProperty("/PreviousItem");
			oPreviousItem = oPreviousItem + 1;
			oHModel.setProperty("/PreviousItem", oPreviousItem);
			oHModel.setProperty("/CurrentItem", oCurrentItem);
			oHModel.setProperty("/NextItem", oNextItem);
			var olen = oHResults.length - 1;
			var olen1 = oHResults.length;
			if (olen === oNextItem) {
				oHModel.setProperty("/EnbNext", false);
				// window.history.go(-1);

			}

			var dialog = new Dialog({
				title: oDErrTyp,
				type: 'Message',
				state: oDErrTyp,
				content: new Text({
					text: oDErrMsg
				}),
				beginButton: new Button({
					text: 'OK',
					press: function () {
						dialog.close();
						if (olen1 === oNextItem) {
							// oHModel.setProperty("/EnbNext", false);
							window.history.go(-1);

						}
						// window.history.go(-1);
						// this.oAddApprovercrt.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();

			if (oHResults[oCurrentItem].InspectLotnumber !== undefined) {
				oHModel.setProperty("/InspectionLotNumber", oHResults[oCurrentItem].InspectLotnumber);
				oHModel.setProperty("/Serialnumber", oHResults[oCurrentItem].Serialnumber);
				oHModel.setProperty("/GCoinType", "");
				// oHModel.setProperty("/GCoinStrike", "");
				oHModel.setProperty("/GCoinGrade", "");
				oHModel.setProperty("/GStarGradeCoin", "");
				oHModel.setProperty("/GPlusGradeCoin", "");
				oHModel.setProperty("/GNumGrade", "");
				oHModel.setProperty("/GCoinStrikeCharacters", "");
				oHModel.setProperty("/GTimeSpent", "");
				oHModel.setProperty("/visFld", true);
				oHModel.setProperty("/Text", "");
				oHModel.setProperty("/Text1", "");
				oHModel.setProperty("/Text2", "");
				oHModel.setProperty("/Text3", "");
				oHModel.setProperty("/Text4", "");
				oHModel.setProperty("/Text5", "");
				oHModel.setProperty("/Text6", "");
				oHModel.setProperty("/Text7", "");
				oHModel.setProperty("/Text7", "");
				oHModel.setProperty("/Title", "");
				oHModel.setProperty("/GText", "");
				oHModel.setProperty("/GradNotes", "");
				oHModel.setProperty("/SGC", false);
				oHModel.setProperty("/PGC", false);

			}

		},
		onNavBack: function () {
			window.history.go(-1);
		},
		onSGCSelect: function (oEvent) {
			var oHModel = this.getView().getModel("oHead");
			var CS = oHModel.getProperty("/VCoinStrikeTypes");
			var grade = oHModel.getProperty("/GNumGrade");
			oHModel.setProperty("/GStarGradeCoin", 'S');
			var ngrade = Math.trunc(grade);
			if (oEvent.getSource().getSelected() === true) {
				var SGC = 'S';
			} else {
				SGC = '';
			}
			oHModel.setProperty("/GStarGradeCoin", 'X');
			oHModel.setProperty("/GPlusGradeCoin", ' ');

			var oTitle = CS + ngrade + SGC;
			oHModel.setProperty("/Title", oTitle);
		},
		onPGCSelect: function (oEvent) {
			var oHModel = this.getView().getModel("oHead");
			var CS = oHModel.getProperty("/VCoinStrikeTypes");
			var grade = oHModel.getProperty("/GNumGrade");
			oHModel.setProperty("/GPlusGradeCoin", 'P');
			var ngrade = Math.trunc(grade);
			if (oEvent.getSource().getSelected() === true) {
				var SGC = 'P';
			} else {
				SGC = '';
			}
			oHModel.setProperty("/GStarGradeCoin", ' ');
			oHModel.setProperty("/GPlusGradeCoin", 'X');

			var oTitle = CS + ngrade + SGC;
			oHModel.setProperty("/Title", oTitle);

		}

	});
});