sap.ui.define([
	"zqmen/zqm_encapsulation/test/unit/controller/Main.controller"
], function () {
	"use strict";
});