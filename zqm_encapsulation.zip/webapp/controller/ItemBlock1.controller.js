sap.ui.define(["sap/ui/core/mvc/Controller",
		'sap/m/MessageBox',
		'sap/ui/model/json/JSONModel',
		'sap/ui/model/odata/v2/ODataModel',
		"sap/m/MessageToast",
		"sap/m/Dialog",
		"sap/m/Button",
		"sap/m/Text"
	],
	function (Controller, MessageBox, JSONModel, ODataModel, MessageToast, Dialog, Button, Text) {
		"use strict";
		return Controller.extend("zqmen.zqm_encapsulation.blocks.ItemBlock1", {
			onInit: function () {
				// var oModelSO = this.getOwnerComponent().getModel("oMain");
				// var oFilterGR = new Array();
				// var oModelGR = this.getOwnerComponent().getModel("oGradResults");
				// var SO = oModelSO.getProperty("/iptsoNum");

				// var salesorder = SO.substring(0, 10);
				// // var salesorderitem = SO.substring(10);
				// // oFilter[0] = new sap.ui.model.Filter("SerialNumber", sap.ui.model.FilterOperator.EQ, SO);
				// oFilterGR[0] = new sap.ui.model.Filter("SalesDocument", sap.ui.model.FilterOperator.EQ, salesorder);
				// // oFilter[1] = new sap.ui.model.Filter("SalesOrderItem", sap.ui.model.FilterOperator.EQ, salesorderitem);

				// oModelGR.read("/ZCDSV_ENCAP_FINAL", {
				// 	success: jQuery.proxy(this._setGradResults, this),
				// 	filters: oFilterGR
				// });

			},
			_setGradResults: function (oData, oResults) {
				var oModelSO = this.getOwnerComponent().getModel("oMain");
				// for (var i = 0; i < oData.results.length; i++) {
				// 	var oProduct = oData.results[i];
				// }
				oModelSO.setProperty("/oGradRslts", oData.results);
			},

			handleF4MintMark: function () {
				if (!this.onf4MMhelpdialog) {
					this.onf4MMhelpdialog = sap.ui.xmlfragment("zqmen.zqm_encapsulation.view.onf4MintMark", this);
					this.getView().addDependent(this.onf4MMhelpdialog);
				}
				this.onf4MMhelpdialog.open();
			},
			onSave: function () {
				var oModel = this.getOwnerComponent().getModel("oMainModel");
				var oHModel = this.getView().getModel("oMain");
				this.getView().setBusy(true);
				var oSavedata = oHModel.getProperty("/SaveData");
				//				oSavedata.PlannedTime = "1";
				//				oSavedata.PlannedTimeUnit = "H";oModelSO.setProperty("/oRslts", oData.results[0]);
				var odata = oHModel.getProperty("/oRslts");
				oSavedata = odata;
				oSavedata.StorageLoc = "1040";
				oModel.create('/ZCDSV_ENCAP_FINAL', oSavedata, {
					success: jQuery.proxy(this._handleSaveEncapsData, this)
						// filters: oFilter
				});
			},
			onSavestrglc: function () {
				var oModel = this.getOwnerComponent().getModel("oMainModel");
				var oHModel = this.getView().getModel("oMain");
				this.getView().setBusy(true);
				var oSavedata = oHModel.getProperty("/SaveData");
				// oSavedata.PlannedTime = oHModel.getProperty("/EPlannedTime");
				// oSavedata.PlannedTimeUnit = oHModel.getProperty("/EPlannedTimeUnit");
				//				oSavedata.PlannedTime = "1";
				//				oSavedata.PlannedTimeUnit = "H";
				var odata = oHModel.getProperty("/oRslts");
				oSavedata = odata;

				oSavedata.StorageLoc = "1050";
				oModel.create('/ZCDSV_ENCAP_FINAL', oSavedata, {
					success: jQuery.proxy(this._handleSaveEncapsData, this)
						// filters: oFilter
				});
			},
			// onSave: function () {
			// 	var oModel = this.getOwnerComponent().getModel("oMainModel");
			// 	var oHModel = this.getView().getModel("oMain");
			// 	this.getView().setBusy(true);
			// 	var oSavedata = oHModel.getProperty("/SaveData");
			// 	oSavedata.PlannedTime = oHModel.getProperty("/EPlannedTime");
			// 	oSavedata.PlannedTimeUnit = oHModel.getProperty("/EPlannedTimeUnit");

			// 	oModel.create('/ZCDSV_ENCAPSULATION', oSavedata, {
			// 		success: jQuery.proxy(this._handleSaveEncapsData, this)
			// 			// filters: oFilter
			// 	});

			// },
			_handleSaveEncapsData: function (oData, oResponse) {
				this.getView().setBusy(false);
				var oErrRes = oResponse.headers["sap-message"];
				var oErrMsg = JSON.parse(oErrRes);
				var oErrTyp = oErrMsg.severity;

				if (oErrTyp === "error") {
					var oDErrTyp = "Error";
					var oDErrMsg = oErrMsg.message;
				} else {
					oDErrTyp = "Success";
					oDErrMsg = "Encapsulation Data is Updated Successfully";
				}

				var dialog = new Dialog({
					title: 'Success',
					type: 'Message',
					state: oDErrTyp,
					content: new Text({
						text: oDErrMsg
					}),
					beginButton: new Button({
						text: 'OK',
						press: function () {
							dialog.close();
							window.history.go(-1);
							// this.oAddApprovercrt.close();
						}
					}),
					afterClose: function () {
						dialog.destroy();
					}
				});
				dialog.open();
			}

			// onAfterRendering: function () {
			// 	JsBarcode("#barcode", "12345678");
			// 	JsBarcode("#barcode1", "12345678");
			// 	// /*eslint no-undef: "error"*/
			// 	// var a = JsBarcode("12345678");
			// 	// this.getView().byId("abc").setText(a);
			// }

		});
	});