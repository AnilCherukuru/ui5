sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History"
], function (Controller, oRouter) {
	"use strict";

	return Controller.extend("zqmen.zqm_encapsulation.controller.SearchSO", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf zcv.zcoin_grading.view.SearchSO
		 */
		onInit: function () {
			// this.getRouter().getTargets().display("notFound");
			this.getRouter().attachRouteMatched(this._onRouteMatched, this);
		},
		_onRouteMatched: function () {

		},
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		onSearch: function (oEvent) {
			var t = this;
			var oSONum = this.getView().byId("searchField").getValue();
			if (oSONum !== "") {
				var oModel = this.getOwnerComponent().getModel("oMain");
				oModel.setProperty("/iptsoNum", oSONum);

				t.byId("searchField").setValue(oSONum);
				this.getRouter().getTargets().display("TargetMain");

			}
			// oScan.scan(
			// 	function (mResult) {
			// 		// t.byId("searchField").setValue("cde");
			// 		// alert("We got a bar code\n" +
			// 		// 	"Result: " + mResult.text + "\n" +
			// 		// 	"Format: " + mResult.format + "\n" +
			// 		// 	"Cancelled: " + mResult.cancelled);
			// 		// if (!mResult) {
			// 		// t.byId("searchField").setValue('0000000025');
			// 		// this.getRouter().Initiali
			// 		// }
			// 	},
			// 	function (Error) {
			// 		// alert("Scanning failed: " + Error);
			// 	},
			// );
		},
		onNavBack: function () {
			window.history.go(-1);
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf zcv.zcoin_grading.view.SearchSO
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf zcv.zcoin_grading.view.SearchSO
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf zcv.zcoin_grading.view.SearchSO
		 */
		//	onExit: function() {
		//
		//	}

	});

});