sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/MessageBox',
	'sap/ui/model/json/JSONModel',
	'sap/ui/model/odata/v2/ODataModel',
	"sap/m/MessageToast",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/Text"
], function (Controller, MessageBox, JSONModel, ODataModel, MessageToast, Dialog, Button, Text) {
	"use strict";

	return Controller.extend("zqmen.zqm_encapsulation.controller.Main", {
		onInit: function () {
			var oModel = this.getOwnerComponent().getModel("oMainModel");

			var oFilter = new Array();
			this.getView().setBusy(true);
			var oModelSO = this.getOwnerComponent().getModel("oMain");

			var SO = oModelSO.getProperty("/iptsoNum");
			// oFilter[0] = new sap.ui.model.Filter("SalesDocument", sap.ui.model.FilterOperator.EQ, SO);
			// oModel.read('/ZCDSV_ENCAPSULATION', {
			// 	success: jQuery.proxy(this._getEncapsData, this),
			// 	filters: oFilter
			// });
			var oModelGR = this.getOwnerComponent().getModel("oMainModel");
			var oFilterGR = new Array();

			var salesorder = SO.substring(0, 10);
			// var salesorderitem = SO.substring(10);
			// oFilter[0] = new sap.ui.model.Filter("SerialNumber", sap.ui.model.FilterOperator.EQ, SO);
			oFilterGR[0] = new sap.ui.model.Filter("SalesDocument", sap.ui.model.FilterOperator.EQ, salesorder);
			// oFilter[1] = new sap.ui.model.Filter("SalesOrderItem", sap.ui.model.FilterOperator.EQ, salesorderitem);

			oModelGR.read("/ZCDSV_ENCAP_FINAL", {
				success: jQuery.proxy(this._setGradResults, this),
				filters: oFilterGR
			});
			var oModelGRD = this.getOwnerComponent().getModel("oGrade");
			var oFilterGRD = new Array();

			// var salesorder = SO.substring(0, 10);
			// var salesorderitem = SO.substring(10);
			// oFilter[0] = new sap.ui.model.Filter("SerialNumber", sap.ui.model.FilterOperator.EQ, SO);
			// oFilterGRD[0] = new sap.ui.model.Filter("Salesordnumber", sap.ui.model.FilterOperator.EQ, salesorder);
			// oFilter[1] = new sap.ui.model.Filter("SalesOrderItem", sap.ui.model.FilterOperator.EQ, salesorderitem);

			// oModelGRD.read("/ZCDSV_QM_GRADING", {
			// 	success: jQuery.proxy(this._setGrade, this),
			// 	filters: oFilterGRD
			// });

		},
		_setGrade: function (oData, oresults) {
			var oHModel = this.getOwnerComponent().getModel("oMain");
			var oModelVD = this.getOwnerComponent().getModel("oVerifData");
			if (oData.results[0].Salesordnumber !== "") {
				oHModel.setProperty("/soNum", oData.results[0].Salesordnumber);
				oHModel.setProperty("/soItemNum", oData.results[0].Salesorditem);
				var SO = oData.results[0].Salesordnumber;
				var oFilter = new Array();
				oFilter[0] = new sap.ui.model.Filter("SalesOrder", sap.ui.model.FilterOperator.EQ, SO);
				oModelVD.read('/zc_qm_verification', {
					success: jQuery.proxy(this._getVerifiIB1, this),
					filters: oFilter

				});
			}
		},
		_getVerifiIB1: function (oData, oresponse) {
			var oHModel = this.getOwnerComponent().getModel("oMain");
			oHModel.setProperty("/VYear", oData.results[0].VYear);
			oHModel.setProperty("/VMint1", oData.results[0].VMintMark);
			oHModel.setProperty("/VMintDesc", oData.results[0].MaterialName);
			oHModel.setProperty("/VDenomination", oData.results[0].VDenomination);
			oHModel.setProperty("/VDenominationCurrencyType", oData.results[0].VDenominationCurrencyType);
			oHModel.setProperty("/VPedigree", oData.results[0].VPedigree);
			oHModel.setProperty("/VCoinStrikeTypes", oData.results[0].VCoinStrikeTypes);
			oHModel.setProperty("/CGraded", oData.results[0].VInspLotQty);

			oHModel.setProperty("/GCoinStrike", oData.results[0].VCoinStrikeTypes);
			oHModel.setProperty("/Title", oData.results[0].VCoinStrikeTypes);

			// oModelSO.setProperty("/oHead", oData.results[0]);
		},
		_setGradResults: function (oData, oResults) {
			this.getView().setBusy(false);
			var oModelSO = this.getOwnerComponent().getModel("oMain");
			oModelSO.setProperty("/oRslts", oData.results[0]);
			for (var i = 0; i < oData.results.length; i++) {
				// var oProduct = oData.results[i];
				oData.results[i].CoinMaterialName = oData.results[i].CoinMaterialName;
				/*				oData.results[i].GCointStrike = oData.results[i].GCointStrike + oData.results[i].GCoinGrade + oData.results[i].GStarGradeCoin +
									oData.results[i].GPlusGradeCoin;*/
			}

			// Customer Details
			oModelSO.setProperty("/soNum", oData.results[0].SalesDocument);
			oModelSO.setProperty("/CName", oData.results[0].CustomerName);
			var streetAdr = oData.results[0].CustomerStreet + ',' + oData.results[0].CustomerPcode;
			oModelSO.setProperty("/CStreet", streetAdr);
			var CtryAdr = oData.results[0].CustomerCity + ',' + oData.results[0].CustomerState;
			oModelSO.setProperty("/CCtryAdr", CtryAdr);
			oModelSO.setProperty("/CCtry", oData.results[0].CustomerCountry);
			// Supplier Details
			oModelSO.setProperty("/SpecStockPartnerName", oData.results[0].SpecStockPartnerName);
			var scstreetAdr = oData.results[0].SpecStockPartnerStreet;
			oModelSO.setProperty("/SCStreet", scstreetAdr);
			var scCtryAdr = oData.results[0].SpecStockPartnerCity + ',' + oData.results[0].SpecStockPartnterState;
			oModelSO.setProperty("/SCCtryAdr", scCtryAdr);
			oModelSO.setProperty("/SCCtry", oData.results[0].SpecStockPartnerCountry);

			oModelSO.setProperty("/TCoins", oData.results[0].ResQuantity);
			oModelSO.setProperty("/CGraded", oData.results[0].VInspLotQty);
			var oFilterPI = new Array();
			var oMat = oData.results[0].CoinMaterial;
			oFilterPI[0] = new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, oMat);

			var oModelPI = this.getOwnerComponent().getModel("oProductImage");
			oModelPI.read('/C_Product', {
				success: jQuery.proxy(this._getProductImage, this),
				filters: oFilterPI
			});
			var oSONum = oData.results[0].SalesDocument;
			oModelSO.setProperty("/oGradRslts", oData.results);
			var oVModel = this.getOwnerComponent().getModel("oVerifData");
			var oURLparams = {
				"SalesOrder": oSONum

			};
			oVModel.callFunction('/GetEncapStock', {
				method: "GET",
				urlParameters: oURLparams,
				success: jQuery.proxy(this._setGetEncapStock, this)
			});
			// oHModel.setProperty("/EPlannedTimeUnit", oData.results[0].PlannedTimeUnit);
			// this.getView().setBusy(false);

		},
		_setGetEncapStock: function (oData, oResponse) {
			var oJModel = this.getOwnerComponent().getModel("oMain");
			
			 oJModel.setProperty("TCoins",oData.results[0].TotalStock);
			// var oTable = "/DSOITEM/";
			// for (var i = 0; i < oOTABLE.length; i++) {
			// 	for (var j = 0; j < oData.results.length; j++) {
			// 		if (oOTABLE[i].SalesDocumentItem === oData.results[j].Salesitem) {
						
			// 			// oOTABLE[i].RequestedQuantity = oData.results[j].Stock;
			// 			// oOTABLE[i].Material = oData.results[j].Material;
			// 			// oOTABLE[i].ZZ1_HolderType_SDI = oData.results[j].Holdertype;
			// 			// oOTABLE[i].ZZ1_Core_SDI = oData.results[j].Coretype;
			// 			// oOTABLE[i].ZZ1_LabelType_SDI = oData.results[j].Labeltype;
			// 		}
			// 	}
			// }
		},
		_getEncapsData: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oMain");

			oHModel.setProperty("/SaveData", oData.results[0]);

			oHModel.setProperty("/ESalesDocument", oData.results[0].SalesDocument);
			oHModel.setProperty("/ESalesDocumentItem", oData.results[0].SalesDocumentItem);
			oHModel.setProperty("/EServiceOrderno", oData.results[0].ServiceOrderno);
			oHModel.setProperty("/EServiceOrderOper", oData.results[0].ServiceOrderOper);
			oHModel.setProperty("/EOperListCounter", oData.results[0].OperListCounter);
			oHModel.setProperty("/EConfirmation", oData.results[0].Confirmation);
			oHModel.setProperty("/EActivityType", oData.results[0].ActivityType);
			oHModel.setProperty("/EServiceOrderReserv", oData.results[0].ServiceOrderReserv);
			oHModel.setProperty("/EMaterial", oData.results[0].Material);
			oHModel.setProperty("/EMaterialName", oData.results[0].MaterialName);
			oHModel.setProperty("/EPlant", oData.results[0].Plant);
			oHModel.setProperty("/EPlantName", oData.results[0].PlantName);
			oHModel.setProperty("/EStorageLocation", oData.results[0].StorageLocation);
			oHModel.setProperty("/EStorageLocationName", oData.results[0].StorageLocationName);
			oHModel.setProperty("/EResQuantity", oData.results[0].ResQuantity);
			oHModel.setProperty("/EResQuanUOM", oData.results[0].ResQuanUOM);
			oHModel.setProperty("/EObjectID", oData.results[0].ObjectID);
			oHModel.setProperty("/EWorkCenter", oData.results[0].WorkCenter);
			oHModel.setProperty("/EPlannedTime", oData.results[0].PlannedTime);
			oHModel.setProperty("/EPlannedTimeUnit", oData.results[0].PlannedTimeUnit);

			oHModel.setProperty("/Material", oData.results[0].CoinMaterial);
			oHModel.setProperty("/MaterialName", oData.results[0].CoinMaterialName);
			oHModel.setProperty("/CName", oData.results[0].CustomerName);
			oHModel.setProperty("/SpecStockPartnerName", oData.results[0].SpecStockPartnerName);
			var streetAdr = oData.results[0].CustomerStreet + ',' + oData.results[0].CustomerPcode;
			oHModel.setProperty("/CStreet", streetAdr);
			var sstreetAdr = oData.results[0].SpecStockPartnerStreet;
			oHModel.setProperty("/SCStreet", sstreetAdr);
			var CtryAdr = oData.results[0].CustomerCity + ',' + oData.results[0].CustomerState;
			oHModel.setProperty("/CCtryAdr", CtryAdr);
			var SCtryAdr = oData.results[0].SpecStockPartnerCity + ',' + oData.results[0].SpecStockPartnerState;
			oHModel.setProperty("/SCCtryAdr", SCtryAdr);
			oHModel.setProperty("/CCtry", oData.results[0].CustomerCountry);
			oHModel.setProperty("/SCCtry", oData.results[0].SpecStockPartnerCountry);
			oHModel.setProperty("/Confirmation", oData.results[0].Confirmation);
			oHModel.setProperty("/ActivityType", oData.results[0].ActivityType);
			var oFilterPI = new Array();
			var oMat = oData.results[0].CoinMaterial;
			oFilterPI[0] = new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, oMat);

			var oModelPI = this.getOwnerComponent().getModel("oProductImage");
			oModelPI.read('/C_Product', {
				success: jQuery.proxy(this._getProductImage, this),
				filters: oFilterPI
			});
			// oHModel.setProperty("/EPlannedTimeUnit", oData.results[0].PlannedTimeUnit);
			this.getView().setBusy(false);
		},
		onSave: function () {
			var oModel = this.getOwnerComponent().getModel("oMainModel");
			var oHModel = this.getView().getModel("oMain");
			this.getView().setBusy(true);
			var oSavedata = oHModel.getProperty("/SaveData");
			oSavedata.PlannedTime = oHModel.getProperty("/EPlannedTime");
			oSavedata.PlannedTimeUnit = oHModel.getProperty("/EPlannedTimeUnit");
			oSavedata.StorageLoc = "1040";
			oModel.create('/ZCDSV_ENCAPSULATION', oSavedata, {
				success: jQuery.proxy(this._handleSaveEncapsData, this)
					// filters: oFilter
			});
		},
		onSavestrglc: function () {
			var oModel = this.getOwnerComponent().getModel("oMainModel");
			var oHModel = this.getView().getModel("oMain");
			this.getView().setBusy(true);
			var oSavedata = oHModel.getProperty("/SaveData");
			oSavedata.PlannedTime = oHModel.getProperty("/EPlannedTime");
			oSavedata.PlannedTimeUnit = oHModel.getProperty("/EPlannedTimeUnit");
			oSavedata.StorageLoc = "1050";
			oModel.create('/ZCDSV_ENCAPSULATION', oSavedata, {
				success: jQuery.proxy(this._handleSaveEncapsData, this)
					// filters: oFilter
			});
		},
		_getProductImage: function (oData, oResponse) {
			var oHModel = this.getView().getModel("oMain");
			oHModel.setProperty("/oImageURL", oData.results[0].ProductImageURL);
		},
		_handleSaveEncapsData: function (oData, oResponse) {
			this.getView().setBusy(false);
			var oErrRes = oResponse.headers["sap-message"];
			var oErrMsg = JSON.parse(oErrRes);
			var oErrTyp = oErrMsg.severity;

			if (oErrTyp === "error") {
				var oDErrTyp = "Error";
				var oDErrMsg = oErrMsg.message;
			} else {
				oDErrTyp = "Success";
				oDErrMsg = "Encapsulation Data is Updated Successfully";
			}

			var dialog = new Dialog({
				title: 'Success',
				type: 'Message',
				state: oDErrTyp,
				content: new Text({
					text: oDErrMsg
				}),
				beginButton: new Button({
					text: 'OK',
					press: function () {
						dialog.close();
						window.history.go(-1);
						// this.oAddApprovercrt.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
		}

	});
});