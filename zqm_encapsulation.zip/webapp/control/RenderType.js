sap.ui.define("zqmen/zqm_encapsulation/control/RenderType", ["jquery.sap.global"],
	function(jQuery) {
	    "use strict";
	    var RenderType = {
	        svg: "svg",
	        canvas: "canvas",
	        iImg: "img"
	    };
	    return RenderType;
}, true);