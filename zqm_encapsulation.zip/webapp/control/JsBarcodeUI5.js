sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/Control",
	"./RenderType",
	"./Format",
	"./JsBarcode.all.min"
], function (jQuery, Control, renderType, format) {
	"use strict";

	var JsBarcodeUI5 = Control.extend("zqmen.zqm_encapsulation.control.JsBarcodeUI5", {
		metadata: {
			properties: {
				"value": {
					type: "string",
					defaultValue: "defaultValue"
				},
				"renderType": {
					type: "string",
					defaultValue: renderType.svg
				},
				"format": {
					type: "string",
					defaultValue: format.code128
				},
				"width": {
					type: "int",
					defaultValue: 2
				},
				"height": {
					type: "int",
					defaultValue: 100
				},
				"displayValue": {
					type: "boolean",
					defaultValue: true
				},
				"fontOptions": {
					type: "string",
					defaultValue: ""
				},
				"font": {
					type: "string",
					defaultValue: "monospace"
				},
				"textAlign": {
					type: "string",
					defaultValue: "center"
				},
				"textPosition": {
					type: "string",
					defaultValue: "bottom"
				},
				"textMargin": {
					type: "int",
					defaultValue: 2
				},
				"fontSize": {
					type: "int",
					defaultValue: 20
				},
				"background": {
					type: "sap.ui.core.CSSColor",
					defaultValue: "#ffffff"
				},
				"lineColor": {
					type: "sap.ui.core.CSSColor",
					defaultValue: "#000000"
				},
				"margin": {
					type: "int",
					defaultValue: 10
				},
				"marginTop": {
					type: "int"
				},
				"marginBottom": {
					type: "int"
				},
				"marginLeft": {
					type: "int"
				},
				"marginRight": {
					type: "int"
				},
			}
		},
		renderer: function (oRm, oControl) {
			oRm.write("<div ");
			oRm.writeControlData(oControl);
			oRm.addStyle("width", "auto");
			oRm.addStyle("height", "auto");
			oRm.writeClasses();
			oRm.writeStyles();
			oRm.write(">");
			oRm.renderControl(oControl._html);
			oRm.write("</div>");
		}
	});

	JsBarcodeUI5.prototype.init = function () {
		this.barcodeId = this.getId() + "-barcode";
		this._html = new sap.ui.core.HTML({
			content: "<" + this.getRenderType() + " id='" + this.barcodeId + "'></" + this.getRenderType() + ">"
		});
	};

	JsBarcodeUI5.prototype.onAfterRendering = function () {
		this.createBarcode();
	};

	JsBarcodeUI5.prototype.createBarcode = function () {
		JsBarcode(jQuery.sap.domById(this.barcodeId), this.getValue(), this._getBarcodeOptions());
	};

	JsBarcodeUI5.prototype._getBarcodeOptions = function () {
		var mBarcodeOptions = {};
		mBarcodeOptions.format = this.getFormat();
		mBarcodeOptions.width = this.getWidth();
		mBarcodeOptions.height = this.getHeight();
		mBarcodeOptions.displayValue = this.getDisplayValue();
		mBarcodeOptions.fontOptions = this.getFontOptions();
		mBarcodeOptions.font = this.getFont();
		mBarcodeOptions.textAlign = this.getTextAlign();
		mBarcodeOptions.textPosition = this.getTextPosition();
		mBarcodeOptions.textMargin = this.getTextMargin();
		mBarcodeOptions.fontSize = this.getFontSize();
		mBarcodeOptions.background = this.getBackground();
		mBarcodeOptions.lineColor = this.getLineColor();
		mBarcodeOptions.margin = this.getMargin();
		mBarcodeOptions.marginTop = this.getMarginTop();
		mBarcodeOptions.marginBottom = this.getMarginBottom();
		mBarcodeOptions.marginLeft = this.getMarginLeft();
		mBarcodeOptions.marginRight = this.getMarginRight();
		return mBarcodeOptions;
	};
});