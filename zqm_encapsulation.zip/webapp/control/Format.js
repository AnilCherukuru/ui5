sap.ui.define("zqmen/zqm_encapsulation/control/Format", ["jquery.sap.global"],
	function(jQuery) {
	    "use strict";
	    var Format = {
	        code128: "CODE128",
	        code128A: "CODE128A",
	        code128B: "CODE128B",
        	code128C: "CODE128C",
        	ean: "EAN",
        	upc: "UPC",
        	ean8: "EAN8",
        	ean5: "EAN5",
        	ean2: "EAN2",
        	code38: "CODE39",
        	itf14: "ITF14",
        	msi: "MSI",
        	msi10: "MSI10",
        	msi11: "MSI11",
        	msi1010: "MSI1010",
        	msi1110: "MSI1110",
        	pharmacode: "pharmacode"
	    };
	    return Format;
}, true);