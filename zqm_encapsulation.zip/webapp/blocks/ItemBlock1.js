sap.ui.define(["sap/uxap/BlockBase"], function (B) {
	"use strict";
	return B.extend("zqmen.zqm_encapsulation.blocks.ItemBlock1", {
		metadata: {
			views: {
				Collapsed: {
					viewName: "zqmen.zqm_encapsulation.blocks.ItemBlock1",
					type: "XML"
				},
				Expanded: {
					viewName: "zqmen.zqm_encapsulation.blocks.ItemBlock1",
					type: "XML"
				}
			},
			events: {}
		}
	});
});